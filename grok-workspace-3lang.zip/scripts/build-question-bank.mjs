/**
 * Generates original TR-YÖS-style MCQs (not copied from any book).
 * Run: node scripts/build-question-bank.mjs
 */
import { writeFileSync } from "node:fs";

const KEYS = ["A", "B", "C", "D", "E"];

function shuffle(arr, seed) {
  const a = [...arr];
  let s = seed;
  const rnd = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function pack({ id, topicId, difficulty, stemTr, stemBn, answer, distractors, explainTr, explainBn, numeric = true }) {
  const unique = [String(answer), ...distractors.map(String)].filter((v, i, arr) => arr.indexOf(v) === i);
  while (unique.length < 5) unique.push(String(Number(unique[unique.length - 1]) + unique.length + 3));
  const opts = shuffle(unique.slice(0, 5), hash(id));
  const answerKey = KEYS[opts.indexOf(String(answer))];
  return {
    id,
    topicId,
    difficulty,
    stem: { tr: stemTr, bn: stemBn },
    options: opts.map((v, i) => ({
      key: KEYS[i],
      tr: numeric ? String(v) : v,
      bn: numeric ? String(v) : v,
    })),
    answer: answerKey,
    explain: { tr: explainTr, bn: explainBn },
  };
}

function packText({ id, topicId, difficulty, stemTr, stemBn, options, answer, explainTr, explainBn }) {
  return {
    id,
    topicId,
    difficulty,
    stem: { tr: stemTr, bn: stemBn },
    options: options.map((o, i) => ({
      key: KEYS[i],
      tr: o.tr,
      bn: o.bn ?? o.tr,
    })),
    answer,
    explain: { tr: explainTr, bn: explainBn },
  };
}

function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

function gcd(a, b) {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) [a, b] = [b, a % b];
  return a;
}

function lcm(a, b) {
  return Math.abs(a * b) / gcd(a, b);
}

function fact(n) {
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function P(n, r) {
  return fact(n) / fact(n - r);
}

function C(n, r) {
  return fact(n) / (fact(r) * fact(n - r));
}

let bank = [];

// ——— Temel kavramlar ———
bank.push(
  pack({
    id: "temel-01",
    topicId: "temel",
    difficulty: 1,
    stemTr: "$3 + 4 \\times 5 - 6$ işleminin sonucu kaçtır?",
    stemBn: "$3 + 4 \\times 5 - 6$ এর মান কত?",
    answer: 17,
    distractors: [29, 11, 35, 9],
    explainTr: "İşlem önceliği: çarpma önce. $4\\times5=20$, sonra $3+20-6=17$.",
    explainBn: "অপারেশনের ক্রম: আগে গুণ। $4\\times5=20$, তারপর $3+20-6=17$।",
  }),
  pack({
    id: "temel-02",
    topicId: "temel",
    difficulty: 1,
    stemTr: "Ardışık üç tek sayının toplamı 45 ise en büyük sayı kaçtır?",
    stemBn: "পরপর তিনটি বিজোড় সংখ্যার যোগফল ৪৫ হলে সবচেয়ে বড় সংখ্যা কত?",
    answer: 17,
    distractors: [15, 19, 13, 21],
    explainTr: "Sayılar $2k-1, 2k+1, 2k+3$. Toplam $6k+3=45 \\Rightarrow k=7$. Sayılar 13, 15, 17.",
    explainBn: "সংখ্যাগুলো $2k-1, 2k+1, 2k+3$। যোগফল $6k+3=45 \\Rightarrow k=7$। সংখ্যা: ১৩, ১৫, ১৭।",
  }),
  pack({
    id: "temel-03",
    topicId: "temel",
    difficulty: 1,
    stemTr: "7 ile 19 arasındaki tam sayıların toplamı kaçtır? (7 ve 19 dahil)",
    stemBn: "৭ ও ১৯ এর মধ্যবর্তী পূর্ণসংখ্যার যোগফল কত? (৭ ও ১৯ সহ)",
    answer: 169,
    distractors: [162, 154, 175, 143],
    explainTr: "Terim sayısı $19-7+1=13$. Ortalama $(7+19)/2=13$. Toplam $13\\times13=169$.",
    explainBn: "পদের সংখ্যা $19-7+1=13$। গড় $(7+19)/2=13$। যোগফল $13\\times13=169$।",
  }),
  pack({
    id: "temel-04",
    topicId: "temel",
    difficulty: 2,
    stemTr: "$(-3)^2 - 3^2 + (-2)^3$ işleminin sonucu kaçtır?",
    stemBn: "$(-3)^2 - 3^2 + (-2)^3$ এর মান কত?",
    answer: -8,
    distractors: [8, 10, -10, 0],
    explainTr: "$9 - 9 + (-8) = -8$.",
    explainBn: "$9 - 9 + (-8) = -8$।",
  }),
  pack({
    id: "temel-05",
    topicId: "temel",
    difficulty: 1,
    stemTr: "İlk 20 doğal sayının toplamı kaçtır?",
    stemBn: "প্রথম ২০টি প্রাকৃতিক সংখ্যার যোগফল কত?",
    answer: 210,
    distractors: [200, 220, 190, 231],
    explainTr: "$n(n+1)/2 = 20\\times21/2 = 210$.",
    explainBn: "$n(n+1)/2 = 20\\times21/2 = 210$।",
  }),
  pack({
    id: "temel-06",
    topicId: "temel",
    difficulty: 2,
    stemTr: "Bir sayının 3 katının 5 eksiği 16 ise sayı kaçtır?",
    stemBn: "একটি সংখ্যার ৩ গুণের থেকে ৫ কমলে ১৬ হয়। সংখ্যাটি কত?",
    answer: 7,
    distractors: [5, 6, 8, 11],
    explainTr: "$3x-5=16 \\Rightarrow 3x=21 \\Rightarrow x=7$.",
    explainBn: "$3x-5=16 \\Rightarrow 3x=21 \\Rightarrow x=7$।",
  }),
  pack({
    id: "temel-07",
    topicId: "temel",
    difficulty: 2,
    stemTr: "$12 \\div 3 \\times 2 + 4$ işleminin sonucu kaçtır?",
    stemBn: "$12 \\div 3 \\times 2 + 4$ এর মান কত?",
    answer: 12,
    distractors: [6, 8, 10, 16],
    explainTr: "Soldan sağa: $12\\div3=4$, $4\\times2=8$, $8+4=12$.",
    explainBn: "বাম থেকে ডান: $12\\div3=4$, $4\\times2=8$, $8+4=12$।",
  }),
  pack({
    id: "temel-08",
    topicId: "temel",
    difficulty: 2,
    stemTr: "Ardışık dört çift sayının toplamı 76 ise en küçük sayı kaçtır?",
    stemBn: "পরপর চারটি জোড় সংখ্যার যোগফল ৭৬ হলে সবচেয়ে ছোট সংখ্যা কত?",
    answer: 16,
    distractors: [14, 18, 12, 20],
    explainTr: "$n+(n+2)+(n+4)+(n+6)=76 \\Rightarrow 4n+12=76 \\Rightarrow n=16$.",
    explainBn: "$n+(n+2)+(n+4)+(n+6)=76 \\Rightarrow 4n+12=76 \\Rightarrow n=16$।",
  }),
  pack({
    id: "temel-09",
    topicId: "temel",
    difficulty: 3,
    stemTr: "$|3-8| - |2-9| + 5$ işleminin sonucu kaçtır?",
    stemBn: "$|3-8| - |2-9| + 5$ এর মান কত?",
    answer: 3,
    distractors: [5, 7, -3, 1],
    explainTr: "$5 - 7 + 5 = 3$.",
    explainBn: "$5 - 7 + 5 = 3$।",
  }),
  pack({
    id: "temel-10",
    topicId: "temel",
    difficulty: 1,
    stemTr: "15’in pozitif tam sayı çarpanlarının sayısı kaçtır?",
    stemBn: "১৫ এর ধনাত্মক পূর্ণসংখ্যা উৎপাদকের সংখ্যা কত?",
    answer: 4,
    distractors: [3, 5, 6, 2],
    explainTr: "$15=3\\times5$. Çarpanlar: 1, 3, 5, 15. Dört tane.",
    explainBn: "$15=3\\times5$। উৎপাদক: ১, ৩, ৫, ১৫। চারটি।",
  }),
);

// ——— Sayılar ———
bank.push(
  packText({
    id: "sayilar-01",
    topicId: "sayilar",
    difficulty: 1,
    stemTr: "$\\sqrt{2}$ sayısı hangi kümeye aittir ama $\\mathbb{Q}$ kümesine ait değildir?",
    stemBn: "$\\sqrt{2}$ কোন সেটে আছে কিন্তু $\\mathbb{Q}$ তে নেই?",
    options: [
      { tr: "Doğal sayılar", bn: "প্রাকৃতিক সংখ্যা" },
      { tr: "Tam sayılar", bn: "পূর্ণসংখ্যা" },
      { tr: "Rasyonel sayılar", bn: "মূলদ সংখ্যা" },
      { tr: "İrrasyonel sayılar", bn: "অমূলদ সংখ্যা" },
      { tr: "Karmaşık olmayan tam", bn: "অসম্পূর্ণ পূর্ণ" },
    ],
    answer: "D",
    explainTr: "$\\sqrt{2}$ irrasyonel bir gerçek sayıdır; kesir olarak yazılamaz.",
    explainBn: "$\\sqrt{2}$ অমূলদ বাস্তব সংখ্যা; ভগ্নাংশ হিসেবে লেখা যায় না।",
  }),
  packText({
    id: "sayilar-02",
    topicId: "sayilar",
    difficulty: 1,
    stemTr: "$\\mathbb{N} \\subset \\mathbb{Z} \\subset \\mathbb{Q} \\subset \\mathbb{R}$ ifadesi için hangisi doğrudur?",
    stemBn: "$\\mathbb{N} \\subset \\mathbb{Z} \\subset \\mathbb{Q} \\subset \\mathbb{R}$ সম্পর্কে কোনটি সত্য?",
    options: [
      { tr: "Yanlıştır, çünkü Z, N’yi kapsamaz", bn: "মিথ্যা, Z তে N নেই" },
      { tr: "Doğrudur", bn: "সত্য" },
      { tr: "Sadece N ⊂ Z doğrudur", bn: "শুধু N ⊂ Z সত্য" },
      { tr: "Q, R’nin alt kümesi değildir", bn: "Q, R এর উপসেট নয়" },
      { tr: "Z ⊂ Q yanlıştır", bn: "Z ⊂ Q মিথ্যা" },
    ],
    answer: "B",
    explainTr: "Doğal ⊂ tam ⊂ rasyonel ⊂ gerçek — standart zincir.",
    explainBn: "প্রাকৃতিক ⊂ পূর্ণ ⊂ মূলদ ⊂ বাস্তব — আদর্শ শৃঙ্খল।",
  }),
  pack({
    id: "sayilar-03",
    topicId: "sayilar",
    difficulty: 2,
    stemTr: "$-7, 0, 4, \\dfrac{2}{3}, \\sqrt{9}$ sayılarından kaç tanesi tam sayıdır?",
    stemBn: "$-7, 0, 4, \\dfrac{2}{3}, \\sqrt{9}$ এর মধ্যে কয়টি পূর্ণসংখ্যা?",
    answer: 4,
    distractors: [3, 5, 2, 1],
    explainTr: "$-7, 0, 4, \\sqrt{9}=3$ tam sayıdır. $2/3$ rasyonel ama tam değil.",
    explainBn: "$-7, 0, 4, \\sqrt{9}=3$ পূর্ণসংখ্যা। $2/3$ মূলদ কিন্তু পূর্ণ নয়।",
  }),
  pack({
    id: "sayilar-04",
    topicId: "sayilar",
    difficulty: 2,
    stemTr: "$\\pi$ ile $22/7$ arasındaki fark yaklaşık olarak hangi aralıktadır? ($\\pi \\approx 3{,}14$)",
    stemBn: "$\\pi$ ও $22/7$ এর পার্থক্য প্রায় কোন ব্যবধানে? ($\\pi \\approx 3{,}14$)",
    answer: 0.003,
    distractors: [0.03, 0.3, 0.14, 0.01],
    explainTr: "$22/7 \\approx 3{,}1429$, $\\pi \\approx 3{,}1416$, fark $\\approx 0{,}0013$ — en yakın $0{,}003$.",
    explainBn: "$22/7 \\approx 3.1429$, $\\pi \\approx 3.1416$, পার্থক্য $\\approx 0.0013$ — সবচেয়ে কাছে $0.003$।",
  }),
  packText({
    id: "sayilar-05",
    topicId: "sayilar",
    difficulty: 1,
    stemTr: "Hangisi rasyonel sayıdır?",
    stemBn: "কোনটি মূলদ সংখ্যা?",
    options: [
      { tr: "$\\sqrt{8}$", bn: "$\\sqrt{8}$" },
      { tr: "$\\sqrt{7}$", bn: "$\\sqrt{7}$" },
      { tr: "$\\sqrt{9/4}$", bn: "$\\sqrt{9/4}$" },
      { tr: "$\\sqrt{12}$", bn: "$\\sqrt{12}$" },
      { tr: "$\\pi-3$", bn: "$\\pi-3$" },
    ],
    answer: "C",
    explainTr: "$\\sqrt{9/4}=3/2$ rasyoneldir. Diğer kökler (ve $\\pi-3$) irrasyonel.",
    explainBn: "$\\sqrt{9/4}=3/2$ মূলদ। বাকি করুণী (এবং $\\pi-3$) অমূলদ।",
  }),
  pack({
    id: "sayilar-06",
    topicId: "sayilar",
    difficulty: 2,
    stemTr: "$-12$ ile $8$ arasındaki tam sayıların adedi kaçtır? (uçlar dahil)",
    stemBn: "$-12$ থেকে $8$ পর্যন্ত পূর্ণসংখ্যা কয়টি? (দুই প্রান্তসহ)",
    answer: 21,
    distractors: [20, 19, 22, 18],
    explainTr: "$8-(-12)+1=21$.",
    explainBn: "$8-(-12)+1=21$।",
  }),
  pack({
    id: "sayilar-07",
    topicId: "sayilar",
    difficulty: 3,
    stemTr: "Pozitif çift tam sayıların kümesi hangisiyle gösterilir?",
    stemBn: "ধনাত্মক জোড় পূর্ণসংখ্যার সেট কোনটি?",
    answer: 2,
    distractors: [1, 3, 4, 0],
    explainTr: "Bu sorunun sayısal şıkları yerine: küme $\\{2,4,6,\\ldots\\}=2\\mathbb{N}$. Seçeneklerde ‘2’ $2\\mathbb{N}$ temsilidir — pratikte metin sorusu.",
    explainBn: "সেট $\\{2,4,6,\\ldots\\}=2\\mathbb{N}$।",
  }),
);

// Fix sayilar-07 — it's a bad numeric question. Replace with text.
bank = bank.filter((q) => q.id !== "sayilar-07");

bank.push(
  packText({
    id: "sayilar-07",
    topicId: "sayilar",
    difficulty: 2,
    stemTr: "Pozitif çift tam sayılar kümesi aşağıdakilerden hangisidir?",
    stemBn: "ধনাত্মক জোড় পূর্ণসংখ্যার সেট কোনটি?",
    options: [
      { tr: "$\\{0,2,4,6,\\ldots\\}$", bn: "$\\{0,2,4,6,\\ldots\\}$" },
      { tr: "$\\{2,4,6,8,\\ldots\\}$", bn: "$\\{2,4,6,8,\\ldots\\}$" },
      { tr: "$\\{\\ldots,-4,-2,0,2,4,\\ldots\\}$", bn: "$\\{\\ldots,-4,-2,0,2,4,\\ldots\\}$" },
      { tr: "$\\{1,3,5,7,\\ldots\\}$", bn: "$\\{1,3,5,7,\\ldots\\}$" },
      { tr: "$\\{1,2,3,4,\\ldots\\}$", bn: "$\\{1,2,3,4,\\ldots\\}$" },
    ],
    answer: "B",
    explainTr: "Pozitif çift: 2, 4, 6, …  Sıfır pozitif değildir.",
    explainBn: "ধনাত্মক জোড়: ২, ৪, ৬, … শূন্য ধনাত্মক নয়।",
  }),
  pack({
    id: "sayilar-08",
    topicId: "sayilar",
    difficulty: 2,
    stemTr: "$-3, -1, 0, 2, 5$ sayılarının en küçüğü ile en büyüğünün çarpımı kaçtır?",
    stemBn: "$-3, -1, 0, 2, 5$ এর ক্ষুদ্রতম ও বৃহত্তমের গুণফল কত?",
    answer: -15,
    distractors: [15, -10, 0, -6],
    explainTr: "En küçük $-3$, en büyük $5$. Çarpım $-15$.",
    explainBn: "ক্ষুদ্রতম $-3$, বৃহত্তম $5$। গুণফল $-15$।",
  }),
  pack({
    id: "sayilar-09",
    topicId: "sayilar",
    difficulty: 1,
    stemTr: "0 doğal sayı kabul edilirse, 0 dahil ilk 5 doğal sayının toplamı kaçtır?",
    stemBn: "০-কে প্রাকৃতিক ধরলে, ০ সহ প্রথম ৫টি প্রাকৃতিক সংখ্যার যোগফল কত?",
    answer: 10,
    distractors: [15, 6, 14, 9],
    explainTr: "$0+1+2+3+4=10$.",
    explainBn: "$0+1+2+3+4=10$।",
  }),
  packText({
    id: "sayilar-10",
    topicId: "sayilar",
    difficulty: 2,
    stemTr: "Hangisi her zaman bir tam sayıdır?",
    stemBn: "কোনটি সবসময় পূর্ণসংখ্যা?",
    options: [
      { tr: "İki tek sayının bölümü", bn: "দুই বিজোড়ের ভাগফল" },
      { tr: "İki tek sayının toplamı", bn: "দুই বিজোড়ের যোগফল" },
      { tr: "Bir irrasyonelin karesi", bn: "একটি অমূলদের বর্গ" },
      { tr: "İki rasyonelin bölümü", bn: "দুই মূলদের ভাগফল" },
      { tr: "Bir gerçelin yarısı", bn: "একটি বাস্তবের অর্ধেক" },
    ],
    answer: "B",
    explainTr: "Tek+tek = çift tam sayı. Diğerleri her zaman tam olmak zorunda değil.",
    explainBn: "বিজোড়+বিজোড় = জোড় পূর্ণসংখ্যা। বাকিগুলো সবসময় পূর্ণ নয়।",
  }),
);

// ——— Rasyonel ———
bank.push(
  pack({
    id: "rasyonel-01",
    topicId: "rasyonel",
    difficulty: 1,
    stemTr: "$\\dfrac{2}{3} + \\dfrac{5}{6}$ işleminin sonucu kaçtır?",
    stemBn: "$\\dfrac{2}{3} + \\dfrac{5}{6}$ এর মান কত?",
    answer: "3/2",
    distractors: ["7/9", "7/6", "1", "5/3"],
    explainTr: "$4/6 + 5/6 = 9/6 = 3/2$.",
    explainBn: "$4/6 + 5/6 = 9/6 = 3/2$।",
    numeric: false,
  }),
  pack({
    id: "rasyonel-02",
    topicId: "rasyonel",
    difficulty: 1,
    stemTr: "$\\dfrac{3}{4} \\times \\dfrac{8}{9}$ işleminin sonucu kaçtır?",
    stemBn: "$\\dfrac{3}{4} \\times \\dfrac{8}{9}$ এর মান কত?",
    answer: "2/3",
    distractors: ["24/36", "11/13", "1/3", "3/2"],
    explainTr: "$24/36 = 2/3$.",
    explainBn: "$24/36 = 2/3$।",
    numeric: false,
  }),
  pack({
    id: "rasyonel-03",
    topicId: "rasyonel",
    difficulty: 2,
    stemTr: "$0{,}25 + 0{,}5 - 0{,}125$ işleminin sonucu kaçtır?",
    stemBn: "$0{,}25 + 0{,}5 - 0{,}125$ এর মান কত?",
    answer: "0.625",
    distractors: ["0.375", "0.75", "0.5", "0.875"],
    explainTr: "$1/4 + 1/2 - 1/8 = 2/8 + 4/8 - 1/8 = 5/8 = 0{,}625$.",
    explainBn: "$1/4 + 1/2 - 1/8 = 5/8 = 0.625$।",
    numeric: false,
  }),
  pack({
    id: "rasyonel-04",
    topicId: "rasyonel",
    difficulty: 2,
    stemTr: "$\\dfrac{5}{12} \\div \\dfrac{10}{9}$ işleminin sonucu kaçtır?",
    stemBn: "$\\dfrac{5}{12} \\div \\dfrac{10}{9}$ এর মান কত?",
    answer: "3/8",
    distractors: ["2/5", "1/2", "5/8", "9/24"],
    explainTr: "$\\dfrac{5}{12}\\times\\dfrac{9}{10}=\\dfrac{45}{120}=\\dfrac{3}{8}$.",
    explainBn: "$\\dfrac{5}{12}\\times\\dfrac{9}{10}=\\dfrac{3}{8}$।",
    numeric: false,
  }),
  packText({
    id: "rasyonel-05",
    topicId: "rasyonel",
    difficulty: 2,
    stemTr: "Hangisi en büyüktür?",
    stemBn: "কোনটি সবচেয়ে বড়?",
    options: [
      { tr: "$\\dfrac{2}{5}$", bn: "$\\dfrac{2}{5}$" },
      { tr: "$\\dfrac{3}{8}$", bn: "$\\dfrac{3}{8}$" },
      { tr: "$\\dfrac{5}{12}$", bn: "$\\dfrac{5}{12}$" },
      { tr: "$\\dfrac{4}{9}$", bn: "$\\dfrac{4}{9}$" },
      { tr: "$\\dfrac{1}{3}$", bn: "$\\dfrac{1}{3}$" },
    ],
    answer: "D",
    explainTr: "$2/5=0{,}4$, $3/8=0{,}375$, $5/12\\approx0{,}417$, $4/9\\approx0{,}444$, $1/3\\approx0{,}333$. En büyük $4/9$.",
    explainBn: "$4/9 \\approx 0.444$ সবচেয়ে বড়।",
  }),
  pack({
    id: "rasyonel-06",
    topicId: "rasyonel",
    difficulty: 2,
    stemTr: "$\\dfrac{1}{2} + \\dfrac{1}{3} + \\dfrac{1}{6}$ işleminin sonucu kaçtır?",
    stemBn: "$\\dfrac{1}{2} + \\dfrac{1}{3} + \\dfrac{1}{6}$ এর মান কত?",
    answer: 1,
    distractors: ["5/6", "2/3", "7/6", "1/2"],
    explainTr: "$3/6 + 2/6 + 1/6 = 1$.",
    explainBn: "$3/6 + 2/6 + 1/6 = 1$।",
    numeric: false,
  }),
  pack({
    id: "rasyonel-07",
    topicId: "rasyonel",
    difficulty: 3,
    stemTr: "Bir sayının $\\dfrac{3}{5}$’i 24 ise sayının $\\dfrac{2}{3}$’ü kaçtır?",
    stemBn: "একটি সংখ্যার $\\dfrac{3}{5}$ অংশ ২৪ হলে তার $\\dfrac{2}{3}$ কত?",
    answer: 32,
    distractors: [40, 30, 36, 28],
    explainTr: "Sayı $=24\\times5/3=40$. $2/3$’ü $= 80/3$ değil: $40\\times2/3=80/3$? Wait $40*2/3=80/3\\approx26.67$ — WRONG. 40*(2/3)=80/3. Recalc.",
    explainBn: "placeholder",
  }),
);

// Fix rasyonel-07
bank = bank.filter((q) => q.id !== "rasyonel-07");
bank.push(
  pack({
    id: "rasyonel-07",
    topicId: "rasyonel",
    difficulty: 3,
    stemTr: "Bir sayının $\\dfrac{3}{5}$’i 24 ise sayının $\\dfrac{5}{8}$’i kaçtır?",
    stemBn: "একটি সংখ্যার $\\dfrac{3}{5}$ অংশ ২৪ হলে তার $\\dfrac{5}{8}$ কত?",
    answer: 25,
    distractors: [20, 30, 40, 15],
    explainTr: "Sayı $=24\\times5/3=40$. $\\dfrac{5}{8}\\times40=25$.",
    explainBn: "সংখ্যা $=24\\times5/3=40$। $\\dfrac{5}{8}\\times40=25$।",
  }),
  pack({
    id: "rasyonel-08",
    topicId: "rasyonel",
    difficulty: 2,
    stemTr: "$2{,}5 \\times 1{,}2$ işleminin sonucu kaçtır?",
    stemBn: "$2{,}5 \\times 1{,}2$ এর মান কত?",
    answer: 3,
    distractors: [2.7, 3.7, 4, 2.4],
    explainTr: "$5/2 \\times 6/5 = 3$.",
    explainBn: "$5/2 \\times 6/5 = 3$।",
  }),
  pack({
    id: "rasyonel-09",
    topicId: "rasyonel",
    difficulty: 3,
    stemTr: "$\\left(\\dfrac{2}{3}\\right)^{-2}$ ifadesinin değeri kaçtır?",
    stemBn: "$\\left(\\dfrac{2}{3}\\right)^{-2}$ এর মান কত?",
    answer: "9/4",
    distractors: ["4/9", "3/2", "-4/9", "6/5"],
    explainTr: "$(3/2)^2 = 9/4$.",
    explainBn: "$(3/2)^2 = 9/4$।",
    numeric: false,
  }),
  pack({
    id: "rasyonel-10",
    topicId: "rasyonel",
    difficulty: 1,
    stemTr: "$\\dfrac{7}{8}$ kesrinin ondalık karşılığı kaçtır?",
    stemBn: "$\\dfrac{7}{8}$ এর দশমিক মান কত?",
    answer: 0.875,
    distractors: [0.78, 0.825, 0.9, 0.75],
    explainTr: "$7\\div8=0{,}875$.",
    explainBn: "$7\\div8=0.875$।",
  }),
);

// ——— Faktöriyel ———
bank.push(
  pack({
    id: "faktoriyel-01",
    topicId: "faktoriyel",
    difficulty: 1,
    stemTr: "$5!$ değeri kaçtır?",
    stemBn: "$5!$ এর মান কত?",
    answer: 120,
    distractors: [60, 24, 720, 20],
    explainTr: "$5!=5\\times4\\times3\\times2\\times1=120$.",
    explainBn: "$5!=5\\times4\\times3\\times2\\times1=120$।",
  }),
  pack({
    id: "faktoriyel-02",
    topicId: "faktoriyel",
    difficulty: 1,
    stemTr: "$\\dfrac{6!}{5!}$ değeri kaçtır?",
    stemBn: "$\\dfrac{6!}{5!}$ এর মান কত?",
    answer: 6,
    distractors: [5, 30, 1, 120],
    explainTr: "$6!/5! = 6$.",
    explainBn: "$6!/5! = 6$।",
  }),
  pack({
    id: "faktoriyel-03",
    topicId: "faktoriyel",
    difficulty: 2,
    stemTr: "$\\dfrac{7!}{5!\\,2!}$ değeri kaçtır?",
    stemBn: "$\\dfrac{7!}{5!\\,2!}$ এর মান কত?",
    answer: 21,
    distractors: [42, 14, 35, 7],
    explainTr: "$7\\times6 / 2 = 21$. Bu $C(7,2)$’dir.",
    explainBn: "$7\\times6 / 2 = 21$। এটি $C(7,2)$।",
  }),
  pack({
    id: "faktoriyel-04",
    topicId: "faktoriyel",
    difficulty: 2,
    stemTr: "$4! + 3! - 2!$ işleminin sonucu kaçtır?",
    stemBn: "$4! + 3! - 2!$ এর মান কত?",
    answer: 28,
    distractors: [26, 24, 30, 22],
    explainTr: "$24 + 6 - 2 = 28$.",
    explainBn: "$24 + 6 - 2 = 28$।",
  }),
  pack({
    id: "faktoriyel-05",
    topicId: "faktoriyel",
    difficulty: 2,
    stemTr: "$n! = 720$ ise $n$ kaçtır?",
    stemBn: "$n! = 720$ হলে $n$ কত?",
    answer: 6,
    distractors: [5, 7, 8, 9],
    explainTr: "$6!=720$.",
    explainBn: "$6!=720$।",
  }),
  pack({
    id: "faktoriyel-06",
    topicId: "faktoriyel",
    difficulty: 3,
    stemTr: "$(n+1)! = 20 \\cdot n!$ ise $n$ kaçtır?",
    stemBn: "$(n+1)! = 20 \\cdot n!$ হলে $n$ কত?",
    answer: 19,
    distractors: [20, 18, 10, 5],
    explainTr: "$(n+1)\\,n! = 20\\, n! \\Rightarrow n+1=20 \\Rightarrow n=19$.",
    explainBn: "$(n+1)\\,n! = 20\\, n! \\Rightarrow n+1=20 \\Rightarrow n=19$।",
  }),
  pack({
    id: "faktoriyel-07",
    topicId: "faktoriyel",
    difficulty: 2,
    stemTr: "$\\dfrac{8!}{6!}$ değeri kaçtır?",
    stemBn: "$\\dfrac{8!}{6!}$ এর মান কত?",
    answer: 56,
    distractors: [48, 64, 42, 72],
    explainTr: "$8\\times7=56$.",
    explainBn: "$8\\times7=56$।",
  }),
  pack({
    id: "faktoriyel-08",
    topicId: "faktoriyel",
    difficulty: 3,
    stemTr: "$\\dfrac{n!}{(n-2)!} = 30$ ise $n$ kaçtır?",
    stemBn: "$\\dfrac{n!}{(n-2)!} = 30$ হলে $n$ কত?",
    answer: 6,
    distractors: [5, 7, 8, 10],
    explainTr: "$n(n-1)=30 \\Rightarrow n=6$.",
    explainBn: "$n(n-1)=30 \\Rightarrow n=6$।",
  }),
  pack({
    id: "faktoriyel-09",
    topicId: "faktoriyel",
    difficulty: 1,
    stemTr: "$0!$ değeri kaçtır?",
    stemBn: "$0!$ এর মান কত?",
    answer: 1,
    distractors: [0, 2, undefined, -1].filter((x) => x !== undefined).concat([10, 5]),
    explainTr: "Tanım gereği $0! = 1$.",
    explainBn: "সংজ্ঞা অনুসারে $0! = 1$।",
  }),
  pack({
    id: "faktoriyel-10",
    topicId: "faktoriyel",
    difficulty: 2,
    stemTr: "$3! \\times 4! / 2!$ değeri kaçtır?",
    stemBn: "$3! \\times 4! / 2!$ এর মান কত?",
    answer: 72,
    distractors: [36, 48, 144, 24],
    explainTr: "$6 \\times 24 / 2 = 72$.",
    explainBn: "$6 \\times 24 / 2 = 72$।",
  }),
);

// ——— Basamak ———
bank.push(
  pack({
    id: "basamak-01",
    topicId: "basamak",
    difficulty: 1,
    stemTr: "Üç basamaklı en küçük doğal sayı kaçtır?",
    stemBn: "তিন অঙ্কের ক্ষুদ্রতম প্রাকৃতিক সংখ্যা কত?",
    answer: 100,
    distractors: [101, 99, 111, 999],
    explainTr: "100.",
    explainBn: "১০০।",
  }),
  pack({
    id: "basamak-02",
    topicId: "basamak",
    difficulty: 1,
    stemTr: "487 sayısında onlar basamağındaki rakam kaçtır?",
    stemBn: "৪৮৭ সংখ্যায় দশকের অঙ্ক কত?",
    answer: 8,
    distractors: [4, 7, 48, 80],
    explainTr: "Birler 7, onlar 8, yüzler 4.",
    explainBn: "একক ৭, দশক ৮, শতক ৪।",
  }),
  pack({
    id: "basamak-03",
    topicId: "basamak",
    difficulty: 2,
    stemTr: "Rakamları toplamı 12 olan iki basamaklı en küçük sayı kaçtır?",
    stemBn: "অঙ্কযোগ ১২ এমন দুই অঙ্কের ক্ষুদ্রতম সংখ্যা কত?",
    answer: 39,
    distractors: [48, 57, 93, 30],
    explainTr: "Onlar basamağı mümkün olan en küçük (3), birler 9 → 39.",
    explainBn: "দশক যত ছোট (৩), একক ৯ → ৩৯।",
  }),
  pack({
    id: "basamak-04",
    topicId: "basamak",
    difficulty: 2,
    stemTr: "2345 sayısında 3’ün basamak değeri kaçtır?",
    stemBn: "২৩৪৫ সংখ্যায় ৩-এর স্থানীয় মান কত?",
    answer: 300,
    distractors: [3, 30, 3000, 345],
    explainTr: "3 yüzler basamağında: $3\\times100=300$.",
    explainBn: "৩ শতকে: $3\\times100=300$।",
  }),
  pack({
    id: "basamak-05",
    topicId: "basamak",
    difficulty: 2,
    stemTr: "İki basamaklı bir sayıda onlar basamağı $a$, birler $b$ ise sayı hangisidir?",
    stemBn: "দুই অঙ্কের সংখ্যায় দশক $a$, একক $b$ হলে সংখ্যা কোনটি?",
    answer: "10a+b",
    distractors: ["a+b", "10b+a", "ab", "a+10b"],
    explainTr: "Sayı $10a+b$.",
    explainBn: "সংখ্যা $10a+b$।",
    numeric: false,
  }),
  pack({
    id: "basamak-06",
    topicId: "basamak",
    difficulty: 3,
    stemTr: "İki basamaklı $ab$ sayısının rakamları yer değiştirince 27 artıyor. $b-a$ kaçtır?",
    stemBn: "দুই অঙ্কের $ab$ সংখ্যার অঙ্ক বদলালে ২৭ বাড়ে। $b-a$ কত?",
    answer: 3,
    distractors: [2, 4, 9, 7],
    explainTr: "$(10b+a)-(10a+b)=9(b-a)=27 \\Rightarrow b-a=3$.",
    explainBn: "$9(b-a)=27 \\Rightarrow b-a=3$।",
  }),
  pack({
    id: "basamak-07",
    topicId: "basamak",
    difficulty: 2,
    stemTr: "5 basamaklı en büyük tek sayı kaçtır?",
    stemBn: "৫ অঙ্কের বৃহত্তম বিজোড় সংখ্যা কত?",
    answer: 99999,
    distractors: [99998, 99997, 90000, 11111],
    explainTr: "99999 hem 5 basamaklı hem tektir.",
    explainBn: "৯৯৯৯৯ পাঁচ অঙ্ক এবং বিজোড়।",
  }),
  pack({
    id: "basamak-08",
    topicId: "basamak",
    difficulty: 3,
    stemTr: "$\\overline{3x5}$ sayısı 5 ile tam bölünüyorsa $x$ hangi değerlerden birini alamaz? (tek cevap: mümkün olmayanı bulun — $x$ 0-9). 5 ile bölünme birler=0 veya 5. Burada birler zaten 5. $x$ her değeri alabilir. Farklı soru:",
    stemBn: "placeholder",
    answer: 0,
    distractors: [1, 2, 3, 4],
    explainTr: "skip",
    explainBn: "skip",
  }),
);

bank = bank.filter((q) => q.id !== "basamak-08");
bank.push(
  pack({
    id: "basamak-08",
    topicId: "basamak",
    difficulty: 3,
    stemTr: "$\\overline{2x4}$ sayısı 9 ile tam bölünüyorsa $x$ kaçtır?",
    stemBn: "$\\overline{2x4}$ সংখ্যা ৯ দ্বারা নিঃশেষে বিভাজ্য হলে $x$ কত?",
    answer: 3,
    distractors: [2, 4, 5, 6],
    explainTr: "Rakamlar toplamı $2+x+4=6+x$ 9’un katı. $x$ rakam $\\Rightarrow x=3$ ($9$) veya $x=12$ imkânsız. $x=3$.",
    explainBn: "অঙ্কযোগ $6+x$ ৯-এর গুণিতক। $x=3$।",
  }),
  pack({
    id: "basamak-09",
    topicId: "basamak",
    difficulty: 2,
    stemTr: "72 sayısının basamak değerleri toplamı kaçtır?",
    stemBn: "৭২ সংখ্যার স্থানীয় মানগুলোর যোগফল কত?",
    answer: 72,
    distractors: [9, 27, 14, 18],
    explainTr: "$70+2=72$ (sayıya eşit).",
    explainBn: "$70+2=72$ (সংখ্যার সমান)।",
  }),
  pack({
    id: "basamak-10",
    topicId: "basamak",
    difficulty: 2,
    stemTr: "Rakamları farklı üç basamaklı en küçük çift sayı kaçtır?",
    stemBn: "ভিন্ন অঙ্কবিশিষ্ট তিন অঙ্কের ক্ষুদ্রতম জোড় সংখ্যা কত?",
    answer: 102,
    distractors: [100, 104, 120, 112],
    explainTr: "100’de rakam tekrarı var. 102 rakamları farklı ve çifttir.",
    explainBn: "১০০-এ অঙ্ক পুনরাবৃত্তি। ১০২ ভিন্ন অঙ্ক ও জোড়।",
  }),
);

// ——— Bölme ———
bank.push(
  pack({
    id: "bolme-01",
    topicId: "bolme",
    difficulty: 1,
    stemTr: "EBOB$(12,18)$ kaçtır?",
    stemBn: "গসাগু$(12,18)$ কত?",
    answer: 6,
    distractors: [3, 9, 12, 36],
    explainTr: "$12=2^2\\cdot3$, $18=2\\cdot3^2$, EBOB $=2\\cdot3=6$.",
    explainBn: "গসাগু $=2\\cdot3=6$।",
  }),
  pack({
    id: "bolme-02",
    topicId: "bolme",
    difficulty: 1,
    stemTr: "EKOK$(12,18)$ kaçtır?",
    stemBn: "লসাগু$(12,18)$ কত?",
    answer: 36,
    distractors: [6, 24, 54, 72],
    explainTr: "EKOK $=2^2\\cdot3^2=36$. Ayrıca EBOB$\\times$EKOK $=12\\times18$.",
    explainBn: "লসাগু $=2^2\\cdot3^2=36$।",
  }),
  pack({
    id: "bolme-03",
    topicId: "bolme",
    difficulty: 2,
    stemTr: "47 sayısı 5’e bölündüğünde kalan kaçtır?",
    stemBn: "৪৭-কে ৫ দিয়ে ভাগ করলে ভাগশেষ কত?",
    answer: 2,
    distractors: [1, 3, 4, 7],
    explainTr: "$47=9\\times5+2$.",
    explainBn: "$47=9\\times5+2$।",
  }),
  pack({
    id: "bolme-04",
    topicId: "bolme",
    difficulty: 2,
    stemTr: "Bir sayı 6’ya bölününce 4 kalanını veriyor. Bu sayı 3’e bölününce kalan kaçtır?",
    stemBn: "একটি সংখ্যা ৬ দিয়ে ভাগ করলে ভাগশেষ ৪। ৩ দিয়ে ভাগ করলে ভাগশেষ কত?",
    answer: 1,
    distractors: [0, 2, 4, 3],
    explainTr: "$n=6k+4=3(2k)+4 \\Rightarrow 4\\bmod 3=1$.",
    explainBn: "$n=6k+4$, $4\\bmod 3=1$।",
  }),
  pack({
    id: "bolme-05",
    topicId: "bolme",
    difficulty: 2,
    stemTr: "EBOB$(24,36)\\times$EKOK$(24,36)$ çarpımı kaçtır?",
    stemBn: "গসাগু$(24,36)\\times$লসাগু$(24,36)$ কত?",
    answer: 864,
    distractors: [72, 432, 576, 216],
    explainTr: "EBOB$\\times$EKOK $=24\\times36=864$.",
    explainBn: "গসাগু$\\times$লসাগু $=24\\times36=864$।",
  }),
  pack({
    id: "bolme-06",
    topicId: "bolme",
    difficulty: 1,
    stemTr: "Hangisi 3 ile tam bölünür? $125$ için rakamlar toplamı 8, hayır. $123$ için 6, evet. Soru: 123 3’e bölünür mü — sayısal: 123’ü 3’e böl.",
    stemBn: "skip",
    answer: 41,
    distractors: [40, 42, 43, 39],
    explainTr: "$123\\div3=41$.",
    explainBn: "$123\\div3=41$।",
  }),
);

bank = bank.filter((q) => q.id !== "bolme-06");
bank.push(
  pack({
    id: "bolme-06",
    topicId: "bolme",
    difficulty: 1,
    stemTr: "$123 \\div 3$ işleminin sonucu kaçtır?",
    stemBn: "$123 \\div 3$ এর মান কত?",
    answer: 41,
    distractors: [40, 42, 43, 31],
    explainTr: "$1+2+3=6$ 3’e bölünür; $123=3\\times41$.",
    explainBn: "$123=3\\times41$।",
  }),
  pack({
    id: "bolme-07",
    topicId: "bolme",
    difficulty: 3,
    stemTr: "EBOB$(a,b)=6$ ve $a\\cdot b=180$ ise EKOK$(a,b)$ kaçtır?",
    stemBn: "গসাগু$(a,b)=6$ এবং $a\\cdot b=180$ হলে লসাগু$(a,b)$ কত?",
    answer: 30,
    distractors: [36, 24, 18, 12],
    explainTr: "EKOK $=ab/$EBOB $=180/6=30$.",
    explainBn: "লসাগু $=ab/$গসাগু $=180/6=30$।",
  }),
  pack({
    id: "bolme-08",
    topicId: "bolme",
    difficulty: 2,
    stemTr: "2, 3 ve 4’e tam bölünen en küçük pozitif tam sayı kaçtır?",
    stemBn: "২, ৩ ও ৪ দ্বারা নিঃশেষে বিভাজ্য ক্ষুদ্রতম ধনাত্মক পূর্ণসংখ্যা কত?",
    answer: 12,
    distractors: [6, 24, 8, 18],
    explainTr: "EKOK$(2,3,4)=12$.",
    explainBn: "লসাগু$(2,3,4)=12$।",
  }),
  pack({
    id: "bolme-09",
    topicId: "bolme",
    difficulty: 3,
    stemTr: "$n= 5k+3$ biçiminde ise $2n$ sayısı 5’e bölününce kalan kaçtır?",
    stemBn: "$n= 5k+3$ হলে $2n$-কে ৫ দিয়ে ভাগ করলে ভাগশেষ কত?",
    answer: 1,
    distractors: [0, 2, 3, 4],
    explainTr: "$2n=10k+6=5(2k+1)+1$, kalan 1.",
    explainBn: "$2n=10k+6$, ভাগশেষ ১।",
  }),
  pack({
    id: "bolme-10",
    topicId: "bolme",
    difficulty: 2,
    stemTr: "72’nin pozitif bölenlerinin sayısı kaçtır?",
    stemBn: "৭২-এর ধনাত্মক ভাজকের সংখ্যা কত?",
    answer: 12,
    distractors: [8, 9, 10, 16],
    explainTr: "$72=2^3\\cdot3^2$, bölen sayısı $(3+1)(2+1)=12$.",
    explainBn: "$72=2^3\\cdot3^2$, ভাজক $(3+1)(2+1)=12$।",
  }),
);

// ——— Mutlak değer ———
bank.push(
  pack({
    id: "mutlak-01",
    topicId: "mutlak",
    difficulty: 1,
    stemTr: "$|-13|$ değeri kaçtır?",
    stemBn: "$|-13|$ এর মান কত?",
    answer: 13,
    distractors: [-13, 0, 1, 26],
    explainTr: "Mutlak değer uzaklığı verir: 13.",
    explainBn: "পরম মান দূরত্ব: ১৩।",
  }),
  pack({
    id: "mutlak-02",
    topicId: "mutlak",
    difficulty: 1,
    stemTr: "$|5-12| + |3-3|$ işleminin sonucu kaçtır?",
    stemBn: "$|5-12| + |3-3|$ এর মান কত?",
    answer: 7,
    distractors: [4, 10, 0, 17],
    explainTr: "$7 + 0 = 7$.",
    explainBn: "$7 + 0 = 7$।",
  }),
  pack({
    id: "mutlak-03",
    topicId: "mutlak",
    difficulty: 2,
    stemTr: "$|x|=7$ denkleminin çözümlerinin toplamı kaçtır?",
    stemBn: "$|x|=7$ সমীকরণের সমাধানগুলোর যোগফল কত?",
    answer: 0,
    distractors: [7, 14, -7, 1],
    explainTr: "$x=7$ veya $x=-7$, toplam 0.",
    explainBn: "$x=7$ বা $x=-7$, যোগফল ০।",
  }),
  pack({
    id: "mutlak-04",
    topicId: "mutlak",
    difficulty: 2,
    stemTr: "$|2x-4|=10$ ise $x$’in alabileceği değerlerin çarpımı kaçtır?",
    stemBn: "$|2x-4|=10$ হলে $x$-এর সম্ভাব্য মানগুলোর গুণফল কত?",
    answer: -21,
    distractors: [21, 7, -7, 0],
    explainTr: "$2x-4=10$ veya $=-10 \\Rightarrow x=7$ veya $x=-3$. Çarpım $-21$.",
    explainBn: "$x=7$ বা $x=-3$, গুণফল $-21$।",
  }),
  pack({
    id: "mutlak-05",
    topicId: "mutlak",
    difficulty: 2,
    stemTr: "$|x-3| = |x+1|$ ise $x$ kaçtır?",
    stemBn: "$|x-3| = |x+1|$ হলে $x$ কত?",
    answer: 1,
    distractors: [3, -1, 2, 0],
    explainTr: "Orta nokta: $x=(3+(-1))/2=1$.",
    explainBn: "মধ্যবিন্দু: $x=1$।",
  }),
  pack({
    id: "mutlak-06",
    topicId: "mutlak",
    difficulty: 3,
    stemTr: "$|x| < 4$ eşitsizliğinin tam sayı çözümlerinin sayısı kaçtır?",
    stemBn: "$|x| < 4$ অসমতার পূর্ণসংখ্যা সমাধান কয়টি?",
    answer: 7,
    distractors: [8, 9, 4, 6],
    explainTr: "$-4 < x < 4$ tam sayılar: $-3,-2,-1,0,1,2,3$ → 7 tane.",
    explainBn: "$-3$ থেকে $3$ পর্যন্ত ৭টি।",
  }),
  pack({
    id: "mutlak-07",
    topicId: "mutlak",
    difficulty: 2,
    stemTr: "$| -2 | \\times | -5 | - | 3 |$ işleminin sonucu kaçtır?",
    stemBn: "$| -2 | \\times | -5 | - | 3 |$ এর মান কত?",
    answer: 7,
    distractors: [13, -7, 10, -13],
    explainTr: "$2\\times5 - 3 = 7$.",
    explainBn: "$2\\times5 - 3 = 7$।",
  }),
  pack({
    id: "mutlak-08",
    topicId: "mutlak",
    difficulty: 3,
    stemTr: "$|x+2| \\ge 5$ eşitsizliğini sağlayan en küçük pozitif tam sayı kaçtır?",
    stemBn: "$|x+2| \\ge 5$ মেনে চলা ক্ষুদ্রতম ধনাত্মক পূর্ণসংখ্যা কত?",
    answer: 3,
    distractors: [1, 2, 4, 5],
    explainTr: "$x+2 \\le -5$ veya $x+2 \\ge 5 \\Rightarrow x\\le -7$ veya $x\\ge 3$. En küçük pozitif: 3.",
    explainBn: "$x\\le -7$ বা $x\\ge 3$। ক্ষুদ্রতম ধনাত্মক: ৩।",
  }),
  pack({
    id: "mutlak-09",
    topicId: "mutlak",
    difficulty: 1,
    stemTr: "$|7-15+3|$ değeri kaçtır?",
    stemBn: "$|7-15+3|$ এর মান কত?",
    answer: 5,
    distractors: [-5, 19, 11, 4],
    explainTr: "$| -5 | = 5$.",
    explainBn: "$| -5 | = 5$।",
  }),
  pack({
    id: "mutlak-10",
    topicId: "mutlak",
    difficulty: 2,
    stemTr: "$|3x|=18$ ise $x^2$ kaçtır?",
    stemBn: "$|3x|=18$ হলে $x^2$ কত?",
    answer: 36,
    distractors: [6, 18, 9, 54],
    explainTr: "$|x|=6 \\Rightarrow x=\\pm6$, $x^2=36$.",
    explainBn: "$|x|=6$, $x^2=36$।",
  }),
);

console.log("partial count", bank.length);
writeFileSync("/tmp/bank-partial.json", JSON.stringify({ n: bank.length }));
writeFileSync("/workspace/scripts/_partial-bank.json", JSON.stringify(bank, null, 0));
console.log("wrote partial", bank.length);
