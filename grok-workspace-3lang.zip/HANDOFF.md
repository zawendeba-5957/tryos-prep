# TRYOS Helper — handoff

Personal TR-YÖS (Metropol matematik) practice app. **Not a copy of the book.** Original MCQs mapped to the same chapter list.

## What exists

- Tablet-first installable web app (TanStack Start + React 19 + Tailwind v4)
- 23 topics (Matematik 1 + 2), 10 original questions each = **230**
- Practice (instant check + explanation) and exam mode per topic
- Mock test: 40 questions, 50 minutes, no negative marking
- Wrong-answer review, local progress (Zustand + localStorage)
- UI: Bangla / Turkish toggle
- Questions in both languages, KaTeX for math

## What this environment cannot do

Flutter / Play Store APK cannot be compiled here. The live app is a PWA-style web app the user can pin to a tablet home screen. A later Flutter port should reuse `src/data/topics.ts` + `src/data/bank.json`.

## Stack / files

| Path | Role |
|---|---|
| `src/data/topics.ts` | Chapter list (ids, BN/TR names) |
| `src/data/bank.json` | Question bank |
| `src/data/bank.ts` | Loaders + mock picker |
| `src/lib/store.ts` | Progress, language, mock history |
| `src/lib/i18n.ts` | UI copy |
| `src/components/quiz-view.tsx` | Quiz engine |
| `src/routes/index.tsx` | Home / topic grid |
| `src/routes/topic.$topicId.tsx` | Topic intro |
| `src/routes/practice.$topicId.tsx` | Topic quiz |
| `src/routes/mock.tsx` | Mock lobby |
| `src/routes/exam.tsx` | Timed mock |
| `src/routes/review.tsx` | Mistakes |
| `scripts/build-question-bank.mjs` + `-2.mjs` | Regenerates bank |

## Not done / next

- Geometry chapters (separate Metropol geometri book)
- IQ / sayısal yetenek
- Full 1400-question book clone (copyright — keep original items)
- Native Flutter APK (needs Flutter SDK + Android Studio on a computer)
- Per-question bookmarks, spaced repetition
- Official ÖSYM past papers (copyright)

## Product rules

- Auth off, no database
- Preview must stay on `0.0.0.0:8080` via `npm run dev` / `startup.sh`
- Do not copy Metropol wording; keep original items
