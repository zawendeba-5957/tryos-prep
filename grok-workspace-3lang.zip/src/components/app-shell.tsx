import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, ClipboardList, Home, RotateCcw } from "lucide-react";
import { t as i18n, LANG_META } from "@/lib/i18n";
import { LANGS } from "@/data/types";
import { useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", key: "home" as const, icon: Home },
  { to: "/mock", key: "mock" as const, icon: ClipboardList },
  { to: "/review", key: "review" as const, icon: RotateCcw },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const lang = useAppStore((s) => s.lang);
  const setLang = useAppStore((s) => s.setLang);
  const txt = i18n(lang);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  // keep <html lang> in sync so screen readers / hyphenation / fonts pick the right language
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
          <Link to="/" className="flex items-center gap-3 min-h-11">
            <span className="flex size-9 items-center justify-center rounded-md bg-paper text-ink">
              <BookOpen className="size-4" strokeWidth={1.75} />
            </span>
            <span className="leading-none">
              <span className="block font-display text-lg tracking-tight">{txt.app}</span>
              <span className="hidden text-[11px] uppercase tracking-[0.16em] text-muted sm:block">
                TR-YÖS
              </span>
            </span>
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex h-11 items-center gap-2 rounded-md px-3.5 text-sm",
                    active ? "bg-raised text-fg" : "text-muted hover:bg-surface hover:text-fg",
                  )}
                >
                  <Icon className="size-4" strokeWidth={1.75} />
                  {txt[item.key]}
                </Link>
              );
            })}
          </nav>
          <div
            role="radiogroup"
            aria-label="Language"
            className="inline-flex h-11 items-center rounded-md border border-border p-0.5"
          >
            {LANGS.map((code) => {
              const active = code === lang;
              return (
                <button
                  key={code}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  aria-label={LANG_META[code].native}
                  title={LANG_META[code].native}
                  onClick={() => setLang(code)}
                  className={cn(
                    "h-full min-w-10 rounded-[5px] px-2.5 text-sm transition-colors",
                    active ? "bg-raised text-fg" : "text-muted hover:text-fg",
                  )}
                >
                  {LANG_META[code].short}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-6 md:pb-12 md:pt-8">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur-md md:hidden pb-[env(safe-area-inset-bottom)]">
        <div className="grid grid-cols-3">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]",
                  active ? "text-fg" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={1.75} />
                {txt[item.key]}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
