import { cva, type VariantProps } from "class-variance-authority";
import { type ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-medium transition-colors duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 select-none active:scale-[0.98]",
  {
    variants: {
      variant: {
        primary:
          "bg-accent text-accent-fg hover:bg-fg",
        paper:
          "bg-paper text-ink hover:bg-fg",
        ghost:
          "bg-transparent text-fg hover:bg-raised border border-border",
        outline:
          "border border-border bg-surface text-fg hover:bg-raised",
        danger:
          "bg-bad text-bad-fg hover:opacity-90",
        ink: "bg-ink text-paper hover:opacity-90",
        quiet: "border border-rule bg-transparent text-ink hover:bg-[#e8e1d3]",
      },
      size: {
        sm: "h-10 px-3.5 text-sm rounded-md",
        md: "h-12 px-5 text-sm rounded-lg",
        lg: "h-14 px-6 text-base rounded-lg",
        icon: "size-12 rounded-lg",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export const Button = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>
>(({ className, variant, size, type = "button", ...props }, ref) => (
  <button
    ref={ref}
    type={type}
    className={cn(buttonVariants({ variant, size }), className)}
    {...props}
  />
));

Button.displayName = "Button";
