import katex from "katex";
import { useMemo } from "react";
import { cn } from "@/lib/utils";

function renderChunk(chunk: string, display: boolean) {
  try {
    return katex.renderToString(chunk, {
      displayMode: display,
      throwOnError: false,
      strict: "ignore",
    });
  } catch {
    return chunk;
  }
}

export function MathText({ text, className }: { text: string; className?: string }) {
  const parts = useMemo(() => {
    const re = /(\$\$[\s\S]+?\$\$|\$[^$]+\$)/g;
    const out: { html?: string; text?: string; display?: boolean }[] = [];
    let last = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(text))) {
      if (m.index > last) out.push({ text: text.slice(last, m.index) });
      const raw = m[0];
      const display = raw.startsWith("$$");
      const body = display ? raw.slice(2, -2) : raw.slice(1, -1);
      out.push({ html: renderChunk(body, display), display });
      last = m.index + raw.length;
    }
    if (last < text.length) out.push({ text: text.slice(last) });
    return out;
  }, [text]);

  return (
    <span className={cn("leading-relaxed", className)}>
      {parts.map((p, i) =>
        p.html ? (
          <span
            key={i}
            className={p.display ? "my-2 block overflow-x-auto" : "inline"}
            dangerouslySetInnerHTML={{ __html: p.html }}
          />
        ) : (
          <span key={i}>{p.text}</span>
        ),
      )}
    </span>
  );
}
