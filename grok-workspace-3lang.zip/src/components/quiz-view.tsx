import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronLeft, ChevronRight, CircleHelp, X } from "lucide-react";
import type { OptionKey, Question } from "@/data/types";
import { getTopic } from "@/data/topics";
import { MathText } from "@/components/math-text";
import { Button } from "@/components/ui/button";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type Mode = "practice" | "exam";

export function QuizView({
  questions,
  mode,
  sessionKey,
  onExit,
  onComplete,
  timerSeconds,
}: {
  questions: Question[];
  mode: Mode;
  sessionKey: string;
  onExit: () => void;
  onComplete?: (result: { score: number; total: number; seconds: number; picks: Record<string, OptionKey | null> }) => void;
  timerSeconds?: number;
}) {
  const lang = useAppStore((s) => s.lang);
  const txt = t(lang);
  const recordAttempt = useAppStore((s) => s.recordAttempt);
  const setLast = useAppStore((s) => s.setLast);
  const lastIndex = useAppStore((s) => s.lastIndex[sessionKey] ?? 0);

  const [index, setIndex] = useState(() => Math.min(lastIndex, Math.max(0, questions.length - 1)));
  const [picks, setPicks] = useState<Record<string, OptionKey | null>>({});
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [left, setLeft] = useState(timerSeconds ?? 0);
  const [confirm, setConfirm] = useState<"submit" | "leave" | null>(null);
  const [showNav, setShowNav] = useState(false);
  const started = useMemo(() => Date.now(), []);
  const picksRef = useRef(picks);
  picksRef.current = picks;
  const doneRef = useRef(false);

  const q = questions[index];
  const pick = q ? picks[q.id] ?? null : null;
  const shown = q ? !!revealed[q.id] : false;

  function finish(currentPicks = picksRef.current) {
    if (doneRef.current) return;
    doneRef.current = true;
    const score = questions.filter((item) => currentPicks[item.id] === item.answer).length;
    for (const item of questions) {
      const chosen = currentPicks[item.id];
      if (chosen) recordAttempt(item.id, chosen, chosen === item.answer);
    }
    onComplete?.({
      score,
      total: questions.length,
      seconds: Math.round((Date.now() - started) / 1000),
      picks: currentPicks,
    });
  }

  useEffect(() => {
    if (!timerSeconds) return;
    const id = window.setInterval(() => {
      setLeft((n) => {
        if (n <= 1) {
          window.clearInterval(id);
          finish();
          return 0;
        }
        return n - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timerSeconds]);

  function go(next: number) {
    const n = Math.max(0, Math.min(questions.length - 1, next));
    setIndex(n);
    setLast(sessionKey, n);
  }

  function choose(key: OptionKey) {
    if (!q) return;
    if (mode === "exam" && revealed[q.id]) return;
    if (mode === "practice" && revealed[q.id]) return;
    setPicks((p) => ({ ...p, [q.id]: key }));
  }

  function check() {
    if (!q || !pick) return;
    setRevealed((r) => ({ ...r, [q.id]: true }));
    recordAttempt(q.id, pick, pick === q.answer);
  }

  if (!q) return null;

  const clock = timerSeconds
    ? `${String(Math.floor(left / 60)).padStart(2, "0")}:${String(left % 60).padStart(2, "0")}`
    : null;

  const answeredCount = questions.filter((item) => picks[item.id]).length;

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_220px]">
      <div>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => (mode === "exam" ? setConfirm("leave") : onExit())}
            className="inline-flex h-11 items-center gap-1 text-sm text-muted hover:text-fg"
          >
            <ChevronLeft className="size-4" />
            {txt.back}
          </button>
          <div className="flex items-center gap-3 text-sm tabular-nums text-muted">
            {clock ? (
              <span className={cn("rounded-md border border-border px-3 py-2 text-fg", left < 60 && "text-bad-fg bg-bad border-transparent")}>
                {txt.timeLeft} {clock}
              </span>
            ) : null}
            <span>
              {index + 1}
              {txt.of}
              {questions.length}
            </span>
          </div>
        </div>

        <article className="rounded-xl bg-paper p-5 text-ink shadow-paper sm:p-8">
          <div className="mb-5 flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-[0.14em] text-ink-muted">
            <span>{getTopic(q.topicId)?.[lang] ?? q.topicId}</span>
            <span className="text-rule">/</span>
            <span>
              {txt.question} {index + 1}
            </span>
          </div>
          <div className="font-display text-xl leading-snug sm:text-2xl">
            <MathText text={q.stem[lang]} />
          </div>

          <div className="mt-6 grid gap-2.5">
            {q.options.map((opt) => {
              const selected = pick === opt.key;
              const isAnswer = opt.key === q.answer;
              const after = shown;
              return (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => choose(opt.key)}
                  disabled={after && mode === "practice"}
                  className={cn(
                    "flex min-h-14 items-start gap-3 rounded-lg border px-3.5 py-3 text-left transition-colors duration-150",
                    "border-rule bg-paper text-ink",
                    selected && !after && "border-ink bg-[#e8e1d3]",
                    after && isAnswer && "border-ok bg-ok-fg text-ink",
                    after && selected && !isAnswer && "border-bad bg-bad-fg text-ink",
                  )}
                >
                  <span
                    className={cn(
                      "mt-0.5 grid size-8 shrink-0 place-items-center rounded-md border border-rule font-mono text-sm",
                      selected && !after && "border-ink bg-ink text-paper",
                      after && isAnswer && "border-ok bg-ok text-ok-fg",
                      after && selected && !isAnswer && "border-bad bg-bad text-bad-fg",
                    )}
                  >
                    {opt.key}
                  </span>
                  <span className="pt-1 text-base">
                    <MathText text={opt[lang]} />
                  </span>
                  {after && isAnswer ? <Check className="ml-auto mt-1 size-4 text-ok" /> : null}
                  {after && selected && !isAnswer ? <X className="ml-auto mt-1 size-4 text-bad" /> : null}
                </button>
              );
            })}
          </div>

          {mode === "practice" && shown ? (
            <div className="mt-6 rounded-lg border border-rule bg-[#ebe6db] p-4">
              <p className="mb-1 text-[11px] uppercase tracking-[0.14em] text-ink-muted">{txt.explanation}</p>
              <p className="text-[15px] text-ink">
                <MathText text={q.explain[lang]} />
              </p>
            </div>
          ) : null}

          <div className="mt-6 flex flex-wrap gap-2">
            {mode === "practice" && !shown ? (
              <Button variant="ink" onClick={check} disabled={!pick} className="min-w-32">
                {txt.check}
              </Button>
            ) : null}
            <Button
              variant="ink"
              className="min-w-32"
              onClick={() => {
                if (mode === "practice" && !shown && pick) check();
                if (index < questions.length - 1) go(index + 1);
                else if (mode === "exam") setConfirm("submit");
                else onExit();
              }}
            >
              {index === questions.length - 1 ? (mode === "exam" ? txt.submit : txt.finish) : txt.next}
              <ChevronRight className="size-4" />
            </Button>
            {index > 0 ? (
              <Button variant="quiet" onClick={() => go(index - 1)}>
                {txt.prev}
              </Button>
            ) : null}
          </div>
        </article>
      </div>

      <aside className="hidden lg:block">
        <div className="sticky top-24 rounded-xl border border-border bg-surface p-4">
          <p className="mb-3 text-[11px] uppercase tracking-[0.14em] text-muted">{txt.navGrid}</p>
          <div className="grid grid-cols-5 gap-1.5">
            {questions.map((item, i) => {
              const has = !!picks[item.id];
              const ok = revealed[item.id] && picks[item.id] === item.answer;
              const bad = revealed[item.id] && picks[item.id] && picks[item.id] !== item.answer;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => go(i)}
                  className={cn(
                    "grid h-9 place-items-center rounded-sm text-xs tabular-nums",
                    i === index ? "bg-accent text-accent-fg" : "bg-raised text-muted",
                    has && i !== index && "text-fg",
                    ok && "bg-ok text-ok-fg",
                    bad && "bg-bad text-bad-fg",
                  )}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-xs text-muted">
            {answeredCount}/{questions.length} {txt.seen}
          </p>
          {mode === "exam" ? (
            <Button className="mt-4 w-full" onClick={() => setConfirm("submit")}>
              {txt.submit}
            </Button>
          ) : null}
        </div>
      </aside>

      <button
        type="button"
        onClick={() => setShowNav(true)}
        className="fixed bottom-20 right-4 z-20 grid size-12 place-items-center rounded-lg bg-accent text-accent-fg shadow-paper lg:hidden"
        aria-label={txt.navGrid}
      >
        <CircleHelp className="size-5" />
      </button>

      {showNav ? (
        <div className="fixed inset-0 z-40 bg-bg/80 p-4 lg:hidden" onClick={() => setShowNav(false)}>
          <div
            className="mx-auto mt-16 max-w-md rounded-xl border border-border bg-surface p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="mb-3 text-sm text-muted">{txt.navGrid}</p>
            <div className="grid grid-cols-6 gap-1.5">
              {questions.map((item, i) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    go(i);
                    setShowNav(false);
                  }}
                  className={cn(
                    "grid h-10 place-items-center rounded-sm text-xs",
                    i === index ? "bg-accent text-accent-fg" : "bg-raised text-muted",
                    picks[item.id] && i !== index && "text-fg",
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {confirm ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-bg/80 p-4">
          <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6">
            <p className="font-display text-xl">
              {confirm === "submit" ? txt.confirmSubmit : txt.leaveExam}
            </p>
            <div className="mt-5 flex gap-2">
              <Button
                className="flex-1"
                onClick={() => {
                  if (confirm === "submit") finish();
                  else onExit();
                }}
              >
                {confirm === "submit" ? txt.yes : txt.leave}
              </Button>
              <Button variant="ghost" className="flex-1" onClick={() => setConfirm(null)}>
                {confirm === "submit" ? txt.no : txt.stay}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
