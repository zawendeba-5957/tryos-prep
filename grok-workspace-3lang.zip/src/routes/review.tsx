import { createFileRoute, Link } from "@tanstack/react-router";
import { QUESTIONS } from "@/data/bank";
import { getTopic } from "@/data/topics";
import { MathText } from "@/components/math-text";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/review")({ component: ReviewPage });

function ReviewPage() {
  const lang = useAppStore((s) => s.lang);
  const attempts = useAppStore((s) => s.attempts);
  const txt = t(lang);
  const wrong = QUESTIONS.filter((q) => attempts[q.id] && !attempts[q.id].correct);

  if (wrong.length === 0) {
    return (
      <div className="mx-auto max-w-lg py-10">
        <h1 className="font-display text-4xl">{txt.review}</h1>
        <p className="mt-3 text-muted">{txt.emptyReview}</p>
        <Link to="/" className="mt-6 inline-block text-sm underline underline-offset-4">
          {txt.homeCta}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-4xl">{txt.review}</h1>
      <p className="mt-2 text-muted">
        {wrong.length} {txt.questions}
      </p>
      <div className="mt-6 grid gap-3">
        {wrong.map((q) => {
          const topic = getTopic(q.topicId);
          const picked = attempts[q.id]?.picked;
          const pickText = q.options.find((o) => o.key === picked)?.[lang] ?? "—";
          const ansText = q.options.find((o) => o.key === q.answer)?.[lang] ?? "";
          return (
            <article key={q.id} className="rounded-xl border border-border bg-surface p-4 sm:p-5">
              <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{topic?.[lang]}</p>
              <div className="mt-2 text-lg">
                <MathText text={q.stem[lang]} />
              </div>
              <p className="mt-3 text-sm text-bad-fg">
                {txt.wrong}: {picked} · <MathText text={pickText} />
              </p>
              <p className="mt-1 text-sm text-ok-fg">
                {txt.correct}: {q.answer} · <MathText text={ansText} />
              </p>
              <p className="mt-3 text-sm text-muted">
                <MathText text={q.explain[lang]} />
              </p>
              <Link
                to="/practice/$topicId"
                params={{ topicId: q.topicId }}
                className="mt-3 inline-block text-sm underline underline-offset-4"
              >
                {txt.startTopic}
              </Link>
            </article>
          );
        })}
      </div>
    </div>
  );
}
