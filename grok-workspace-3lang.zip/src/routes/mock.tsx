import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ClipboardList } from "lucide-react";
import { useEffect, useState } from "react";
import { pickMockPaper } from "@/data/bank";
import { Button } from "@/components/ui/button";
import { t, LOCALE } from "@/lib/i18n";
import { MOCK_KEY, MOCK_RESULT } from "@/lib/mock-session";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/mock")({ component: MockPage });

function MockPage() {
  const lang = useAppStore((s) => s.lang);
  const txt = t(lang);
  const history = useAppStore((s) => s.mockHistory);
  const navigate = useNavigate();

  const [lastResult, setLastResult] = useState<{ score: number; total: number } | null>(null);

  useEffect(() => {
    try {
      setLastResult(JSON.parse(sessionStorage.getItem(MOCK_RESULT) || "null"));
    } catch {
      setLastResult(null);
    }
  }, []);

  function start() {
    const paper = pickMockPaper(40);
    sessionStorage.setItem(MOCK_KEY, JSON.stringify({ ids: paper.map((q) => q.id), started: Date.now() }));
    sessionStorage.removeItem(MOCK_RESULT);
    navigate({ to: "/exam" });
  }

  return (
    <div className="mx-auto max-w-2xl">
      <p className="text-[11px] uppercase tracking-[0.16em] text-muted">TR-YÖS</p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">{txt.mockTitle}</h1>
      <p className="mt-3 text-muted">{txt.mockBlurb}</p>
      <p className="mt-2 text-sm text-subtle">{txt.noPenalty}</p>

      {lastResult ? (
        <div className="mt-6 rounded-xl bg-paper p-5 text-ink">
          <p className="text-[11px] uppercase tracking-[0.14em] text-ink-muted">{txt.result}</p>
          <p className="mt-1 font-display text-5xl tabular-nums">
            {lastResult.score}
            <span className="text-2xl text-ink-muted">/{lastResult.total}</span>
          </p>
        </div>
      ) : null}

      <Button size="lg" className="mt-8 min-h-14 w-full sm:w-auto" onClick={start}>
        <ClipboardList className="size-4" />
        {txt.startMock}
      </Button>

      {history.length > 0 ? (
        <section className="mt-10">
          <h2 className="font-display text-2xl">{txt.lastScore}</h2>
          <ul className="mt-3 divide-y divide-border rounded-xl border border-border">
            {history.map((h) => (
              <li key={h.id} className="flex items-center justify-between px-4 py-3 text-sm">
                <span className="text-muted">
                  {new Date(h.at).toLocaleDateString(LOCALE[lang])}
                </span>
                <span className="tabular-nums">
                  {h.score}/{h.total}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
