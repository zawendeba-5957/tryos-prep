import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Play } from "lucide-react";
import { questionsForTopic } from "@/data/bank";
import { getTopic, topicBlurb } from "@/data/topics";
import { Button } from "@/components/ui/button";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/topic/$topicId")({ component: TopicPage });

function TopicPage() {
  const { topicId } = Route.useParams();
  const navigate = useNavigate();
  const topic = getTopic(topicId);
  const lang = useAppStore((s) => s.lang);
  const attempts = useAppStore((s) => s.attempts);
  const txt = t(lang);
  const qs = questionsForTopic(topicId);
  const done = qs.filter((q) => attempts[q.id]?.correct).length;

  if (!topic) {
    return (
      <div>
        <p className="text-muted">Missing topic.</p>
        <Link to="/" className="mt-3 inline-block text-sm underline">
          {txt.home}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <button
        type="button"
        onClick={() => navigate({ to: "/" })}
        className="mb-6 inline-flex h-11 items-center gap-1 text-sm text-muted hover:text-fg"
      >
        <ArrowLeft className="size-4" />
        {txt.back}
      </button>
      <p className="text-[11px] uppercase tracking-[0.16em] text-muted">
        {topic.group === "mat1" ? txt.mat1 : txt.mat2} · {String(topic.order).padStart(2, "0")}
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">{topic[lang]}</h1>
      <p className="mt-3 text-muted">{topicBlurb(topic, lang)}</p>

      <div className="mt-6 grid grid-cols-3 gap-3">
        <Mini k={txt.questions} v={String(qs.length)} />
        <Mini k={txt.mastered} v={String(done)} />
        <Mini k={txt.accuracy} v={qs.length ? `${Math.round((done / qs.length) * 100)}%` : "—"} />
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button
          size="lg"
          className="flex-1"
          onClick={() => navigate({ to: "/practice/$topicId", params: { topicId }, search: { mode: "practice" } })}
        >
          <Play className="size-4" />
          {txt.practice}
        </Button>
        <Button
          size="lg"
          variant="outline"
          className="flex-1"
          onClick={() => navigate({ to: "/practice/$topicId", params: { topicId }, search: { mode: "exam" } })}
        >
          {txt.examMode}
        </Button>
      </div>
    </div>
  );
}

function Mini({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-3">
      <p className="text-[11px] uppercase tracking-[0.12em] text-muted">{k}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{v}</p>
    </div>
  );
}
