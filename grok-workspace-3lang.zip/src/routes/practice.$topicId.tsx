import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { questionsForTopic } from "@/data/bank";
import { getTopic } from "@/data/topics";
import { QuizView } from "@/components/quiz-view";
import { Button } from "@/components/ui/button";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import type { OptionKey } from "@/data/types";

type Search = { mode?: "practice" | "exam" };

export const Route = createFileRoute("/practice/$topicId")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    mode: s.mode === "exam" ? "exam" : "practice",
  }),
  component: PracticePage,
});

function PracticePage() {
  const { topicId } = Route.useParams();
  const { mode = "practice" } = Route.useSearch();
  const navigate = useNavigate();
  const lang = useAppStore((s) => s.lang);
  const txt = t(lang);
  const topic = getTopic(topicId);
  const questions = useMemo(() => questionsForTopic(topicId), [topicId]);
  const [summary, setSummary] = useState<{ score: number; total: number } | null>(null);

  if (!topic || questions.length === 0) {
    return (
      <p className="text-muted">
        Missing.{" "}
        <button type="button" className="underline" onClick={() => navigate({ to: "/" })}>
          {txt.home}
        </button>
      </p>
    );
  }

  if (summary) {
    return (
      <div className="mx-auto max-w-md rounded-xl border border-border bg-surface p-6">
        <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{topic[lang]}</p>
        <h1 className="mt-2 font-display text-4xl">{txt.result}</h1>
        <p className="mt-4 font-display text-5xl tabular-nums">
          {summary.score}
          <span className="text-2xl text-muted">/{summary.total}</span>
        </p>
        <div className="mt-6 flex gap-2">
          <Button className="flex-1" onClick={() => setSummary(null)}>
            {txt.again}
          </Button>
          <Button variant="ghost" className="flex-1" onClick={() => navigate({ to: "/" })}>
            {txt.homeCta}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <QuizView
      questions={questions}
      mode={mode}
      sessionKey={topicId}
      onExit={() => navigate({ to: "/topic/$topicId", params: { topicId } })}
      onComplete={(r: { score: number; total: number; seconds: number; picks: Record<string, OptionKey | null> }) => {
        if (mode === "exam") setSummary({ score: r.score, total: r.total });
        else navigate({ to: "/topic/$topicId", params: { topicId } });
      }}
    />
  );
}
