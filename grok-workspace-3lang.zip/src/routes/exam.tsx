import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { QUESTIONS } from "@/data/bank";
import type { Question } from "@/data/types";
import { QuizView } from "@/components/quiz-view";
import { t } from "@/lib/i18n";
import { MOCK_KEY, MOCK_RESULT } from "@/lib/mock-session";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/exam")({ component: ExamPage });

function loadPaper(): Question[] {
  try {
    const raw = sessionStorage.getItem(MOCK_KEY);
    if (!raw) return [];
    const { ids } = JSON.parse(raw) as { ids: string[] };
    const map = new Map(QUESTIONS.map((q) => [q.id, q]));
    return ids.map((id) => map.get(id)).filter(Boolean) as Question[];
  } catch {
    return [];
  }
}

function ExamPage() {
  const navigate = useNavigate();
  const lang = useAppStore((s) => s.lang);
  const txt = t(lang);
  const addMock = useAppStore((s) => s.addMock);
  const recordAttempt = useAppStore((s) => s.recordAttempt);
  const [questions, setQuestions] = useState<Question[] | null>(null);

  useEffect(() => {
    setQuestions(loadPaper());
  }, []);

  if (questions === null) {
    return <p className="text-muted">{txt.progress}…</p>;
  }

  if (questions.length === 0) {
    return (
      <div className="mx-auto max-w-md">
        <p className="text-muted">{txt.mockBlurb}</p>
        <button type="button" className="mt-4 underline" onClick={() => navigate({ to: "/mock" })}>
          {txt.back}
        </button>
      </div>
    );
  }

  return (
    <QuizView
      questions={questions}
      mode="exam"
      sessionKey="mock"
      timerSeconds={50 * 60}
      onExit={() => navigate({ to: "/mock" })}
      onComplete={(r) => {
        for (const q of questions) {
          const picked = r.picks[q.id];
          if (picked) recordAttempt(q.id, picked, picked === q.answer);
        }
        addMock({
          id: String(Date.now()),
          at: Date.now(),
          score: r.score,
          total: r.total,
          seconds: r.seconds,
        });
        sessionStorage.setItem(MOCK_RESULT, JSON.stringify({ score: r.score, total: r.total }));
        sessionStorage.removeItem(MOCK_KEY);
        navigate({ to: "/mock" });
      }}
    />
  );
}
