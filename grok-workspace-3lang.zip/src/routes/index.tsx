import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ClipboardList } from "lucide-react";
import { QUESTIONS, questionsForTopic } from "@/data/bank";
import { TOPICS, topicBlurb } from "@/data/topics";
import type { Lang } from "@/data/types";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const lang = useAppStore((s) => s.lang);
  const attempts = useAppStore((s) => s.attempts);
  const lastTopicId = useAppStore((s) => s.lastTopicId);
  const mockHistory = useAppStore((s) => s.mockHistory);
  const txt = t(lang);

  const answered = Object.keys(attempts).length;
  const correct = Object.values(attempts).filter((a) => a.correct).length;
  const last = TOPICS.find((x) => x.id === lastTopicId);
  const lastMock = mockHistory[0];

  return (
    <div className="grid gap-8">
      <section className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
        <div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-muted">TR-YÖS · Metropol</p>
          <h1 className="mt-2 font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl">{txt.app}</h1>
          <p className="mt-3 max-w-xl text-muted">{txt.tagline}</p>
          <p className="mt-2 max-w-xl text-sm text-subtle">{txt.bookNote}</p>
        </div>
        <div className="grid grid-cols-2 gap-3 self-end sm:grid-cols-3 lg:grid-cols-1">
          <Stat label={txt.seen} value={`${answered}/${QUESTIONS.length}`} />
          <Stat label={txt.accuracy} value={answered ? `${Math.round((correct / answered) * 100)}%` : "—"} />
          <Stat
            label={txt.lastScore}
            value={lastMock ? `${lastMock.score}/${lastMock.total}` : "—"}
            className="col-span-2 sm:col-span-1"
          />
        </div>
      </section>

      <div className="grid gap-3 md:grid-cols-2">
        {last ? (
          <Link
            to="/practice/$topicId"
            params={{ topicId: last.id }}
            className="flex min-h-24 items-center justify-between rounded-xl border border-border bg-surface px-5 py-4 hover:bg-raised"
          >
            <span>
              <span className="block text-[11px] uppercase tracking-[0.14em] text-muted">{txt.continue}</span>
              <span className="mt-1 block font-display text-2xl">{last[lang]}</span>
            </span>
            <ArrowRight className="size-5 text-muted" />
          </Link>
        ) : (
          <Link
            to="/topic/$topicId"
            params={{ topicId: TOPICS[0].id }}
            className="flex min-h-24 items-center justify-between rounded-xl border border-border bg-surface px-5 py-4 hover:bg-raised"
          >
            <span>
              <span className="block text-[11px] uppercase tracking-[0.14em] text-muted">{txt.start}</span>
              <span className="mt-1 block font-display text-2xl">{TOPICS[0][lang]}</span>
            </span>
            <ArrowRight className="size-5 text-muted" />
          </Link>
        )}
        <Link
          to="/mock"
          className="flex min-h-24 items-center justify-between rounded-xl bg-paper px-5 py-4 text-ink hover:opacity-95"
        >
          <span>
            <span className="block text-[11px] uppercase tracking-[0.14em] text-ink-muted">{txt.mock}</span>
            <span className="mt-1 block font-display text-2xl">{txt.mockTitle}</span>
          </span>
          <ClipboardList className="size-5" />
        </Link>
      </div>

      <Group title={txt.mat1} topics={TOPICS.filter((x) => x.group === "mat1")} lang={lang} attempts={attempts} />
      <Group title={txt.mat2} topics={TOPICS.filter((x) => x.group === "mat2")} lang={lang} attempts={attempts} />
    </div>
  );
}

function Stat({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className={cn("rounded-xl border border-border bg-surface px-4 py-3", className)}>
      <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
    </div>
  );
}

function Group({
  title,
  topics,
  lang,
  attempts,
}: {
  title: string;
  topics: typeof TOPICS;
  lang: Lang;
  attempts: ReturnType<typeof useAppStore.getState>["attempts"];
}) {
  return (
    <section>
      <h2 className="mb-3 font-display text-2xl">{title}</h2>
      <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
        {topics.map((topic) => {
          const qs = questionsForTopic(topic.id);
          const done = qs.filter((q) => attempts[q.id]?.correct).length;
          const pct = qs.length ? Math.round((done / qs.length) * 100) : 0;
          return (
            <Link
              key={topic.id}
              to="/topic/$topicId"
              params={{ topicId: topic.id }}
              className="rounded-lg border border-border bg-surface p-4 hover:bg-raised"
            >
              <div className="flex items-start justify-between gap-3">
                <span className="font-mono text-xs tabular-nums text-muted">
                  {String(topic.order).padStart(2, "0")}
                </span>
                <span className="text-xs tabular-nums text-muted">{pct}%</span>
              </div>
              <h3 className="mt-2 font-display text-xl leading-tight">{topic[lang]}</h3>
              <p className="mt-1 line-clamp-2 text-sm text-muted">{topicBlurb(topic, lang)}</p>
              <div className="mt-3 h-1 overflow-hidden rounded-full bg-raised">
                <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
              </div>
              <p className="mt-2 text-xs text-subtle">
                {done}/{qs.length}
              </p>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
