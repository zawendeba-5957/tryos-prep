export const MOCK_KEY = "tryos-mock-live";
export const MOCK_RESULT = "tryos-mock-result";
