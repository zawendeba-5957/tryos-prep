import { create } from "zustand";
import { persist } from "zustand/middleware";
import { LANGS, type Lang, type OptionKey } from "@/data/types";

export type Attempt = {
  picked: OptionKey | null;
  correct: boolean;
  at: number;
};

export type MockRecord = {
  id: string;
  at: number;
  score: number;
  total: number;
  seconds: number;
};

type State = {
  lang: Lang;
  attempts: Record<string, Attempt>;
  lastTopicId: string | null;
  lastIndex: Record<string, number>;
  mockHistory: MockRecord[];
  setLang: (lang: Lang) => void;
  recordAttempt: (questionId: string, picked: OptionKey, correct: boolean) => void;
  setLast: (topicId: string, index: number) => void;
  addMock: (rec: MockRecord) => void;
  clearAttemptsFor: (questionIds: string[]) => void;
};

export const useAppStore = create<State>()(
  persist(
    (set) => ({
      lang: "bn",
      attempts: {},
      lastTopicId: null,
      lastIndex: {},
      mockHistory: [],
      setLang: (lang) => set({ lang }),
      recordAttempt: (questionId, picked, correct) =>
        set((s) => ({
          attempts: {
            ...s.attempts,
            [questionId]: { picked, correct, at: Date.now() },
          },
        })),
      setLast: (topicId, index) =>
        set((s) => ({
          lastTopicId: topicId,
          lastIndex: { ...s.lastIndex, [topicId]: index },
        })),
      addMock: (rec) => set((s) => ({ mockHistory: [rec, ...s.mockHistory].slice(0, 12) })),
      clearAttemptsFor: (questionIds) =>
        set((s) => {
          const next = { ...s.attempts };
          for (const id of questionIds) delete next[id];
          return { attempts: next };
        }),
    }),
    {
      name: "tryos-helper-v1",
      // A stale/corrupt persisted lang would make copy[lang] undefined and crash the UI.
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<State>;
        const lang = LANGS.includes(p.lang as Lang) ? (p.lang as Lang) : current.lang;
        return { ...current, ...p, lang };
      },
    },
  ),
);
