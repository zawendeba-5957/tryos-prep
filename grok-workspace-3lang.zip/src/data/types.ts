export type Lang = "bn" | "en" | "tr";
export const LANGS: Lang[] = ["bn", "en", "tr"];
export type OptionKey = "A" | "B" | "C" | "D" | "E";

export type Question = {
  id: string;
  topicId: string;
  difficulty: 1 | 2 | 3;
  stem: Record<Lang, string>;
  options: ({ key: OptionKey } & Record<Lang, string>)[];
  answer: OptionKey;
  explain: Record<Lang, string>;
};
