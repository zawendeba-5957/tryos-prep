//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-wteTnB1d.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/exam",
			"/mock",
			"/review",
			"/practice/$topicId",
			"/topic/$topicId"
		],
		preloads: [
			"/assets/index-B9tjvhxZ.js",
			"/assets/utils-DTKkZpQ3.js",
			"/assets/link-CxW7eLNI.js",
			"/assets/preload-helper-Dm81Icji.js",
			"/assets/createLucideIcon-DnEtDG8j.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B9tjvhxZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-u5MyVSBv.js", "/assets/bank-B2Ks3kQK.js"]
	},
	"/exam": {
		filePath: "/workspace/src/routes/exam.tsx",
		children: void 0,
		preloads: [
			"/assets/exam-CvsLCu04.js",
			"/assets/useNavigate-BrPZoWgn.js",
			"/assets/quiz-view-BFcOzZL4.js",
			"/assets/bank-B2Ks3kQK.js",
			"/assets/mock-session-DgbndiNx.js"
		]
	},
	"/mock": {
		filePath: "/workspace/src/routes/mock.tsx",
		children: void 0,
		preloads: [
			"/assets/mock-CaMRym2A.js",
			"/assets/useNavigate-BrPZoWgn.js",
			"/assets/bank-B2Ks3kQK.js",
			"/assets/button-TDtRtb5h.js",
			"/assets/mock-session-DgbndiNx.js"
		]
	},
	"/review": {
		filePath: "/workspace/src/routes/review.tsx",
		children: void 0,
		preloads: [
			"/assets/review-Bh5_QOQL.js",
			"/assets/bank-B2Ks3kQK.js",
			"/assets/math-text-1mMe41io.js"
		]
	},
	"/practice/$topicId": {
		filePath: "/workspace/src/routes/practice.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/practice._topicId-CWnqo2kT.js",
			"/assets/useNavigate-BrPZoWgn.js",
			"/assets/quiz-view-BFcOzZL4.js",
			"/assets/bank-B2Ks3kQK.js",
			"/assets/button-TDtRtb5h.js"
		]
	},
	"/topic/$topicId": {
		filePath: "/workspace/src/routes/topic.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/topic._topicId-DcPzFzOX.js",
			"/assets/useNavigate-BrPZoWgn.js",
			"/assets/bank-B2Ks3kQK.js",
			"/assets/button-TDtRtb5h.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
