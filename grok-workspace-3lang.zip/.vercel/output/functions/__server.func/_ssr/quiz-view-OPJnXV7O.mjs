import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as ChevronRight, l as ChevronLeft, s as CircleHelp, t as X, u as Check } from "../_libs/lucide-react.mjs";
import { a as useAppStore, i as cn, o as t } from "./router-DGLBVkyc.mjs";
import { r as getTopic } from "./bank-B_lNkvx6.mjs";
import { t as MathText } from "./math-text-t_PRzwZL.mjs";
import { t as Button } from "./button-CknPAhEX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-view-OPJnXV7O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuizView({ questions, mode, sessionKey, onExit, onComplete, timerSeconds }) {
	const lang = useAppStore((s) => s.lang);
	const txt = t(lang);
	const recordAttempt = useAppStore((s) => s.recordAttempt);
	const setLast = useAppStore((s) => s.setLast);
	const lastIndex = useAppStore((s) => s.lastIndex[sessionKey] ?? 0);
	const [index, setIndex] = (0, import_react.useState)(() => Math.min(lastIndex, Math.max(0, questions.length - 1)));
	const [picks, setPicks] = (0, import_react.useState)({});
	const [revealed, setRevealed] = (0, import_react.useState)({});
	const [left, setLeft] = (0, import_react.useState)(timerSeconds ?? 0);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const [showNav, setShowNav] = (0, import_react.useState)(false);
	const started = (0, import_react.useMemo)(() => Date.now(), []);
	const picksRef = (0, import_react.useRef)(picks);
	picksRef.current = picks;
	const doneRef = (0, import_react.useRef)(false);
	const q = questions[index];
	const pick = q ? picks[q.id] ?? null : null;
	const shown = q ? !!revealed[q.id] : false;
	function finish(currentPicks = picksRef.current) {
		if (doneRef.current) return;
		doneRef.current = true;
		const score = questions.filter((item) => currentPicks[item.id] === item.answer).length;
		for (const item of questions) {
			const chosen = currentPicks[item.id];
			if (chosen) recordAttempt(item.id, chosen, chosen === item.answer);
		}
		onComplete?.({
			score,
			total: questions.length,
			seconds: Math.round((Date.now() - started) / 1e3),
			picks: currentPicks
		});
	}
	(0, import_react.useEffect)(() => {
		if (!timerSeconds) return;
		const id = window.setInterval(() => {
			setLeft((n) => {
				if (n <= 1) {
					window.clearInterval(id);
					finish();
					return 0;
				}
				return n - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [timerSeconds]);
	function go(next) {
		const n = Math.max(0, Math.min(questions.length - 1, next));
		setIndex(n);
		setLast(sessionKey, n);
	}
	function choose(key) {
		if (!q) return;
		if (mode === "exam" && revealed[q.id]) return;
		if (mode === "practice" && revealed[q.id]) return;
		setPicks((p) => ({
			...p,
			[q.id]: key
		}));
	}
	function check() {
		if (!q || !pick) return;
		setRevealed((r) => ({
			...r,
			[q.id]: true
		}));
		recordAttempt(q.id, pick, pick === q.answer);
	}
	if (!q) return null;
	const clock = timerSeconds ? `${String(Math.floor(left / 60)).padStart(2, "0")}:${String(left % 60).padStart(2, "0")}` : null;
	const answeredCount = questions.filter((item) => picks[item.id]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_220px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => mode === "exam" ? setConfirm("leave") : onExit(),
					className: "inline-flex h-11 items-center gap-1 text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), txt.back]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-sm tabular-nums text-muted",
					children: [clock ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("rounded-md border border-border px-3 py-2 text-fg", left < 60 && "text-bad-fg bg-bad border-transparent"),
						children: [
							txt.timeLeft,
							" ",
							clock
						]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						index + 1,
						txt.of,
						questions.length
					] })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-paper p-5 text-ink shadow-paper sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-[0.14em] text-ink-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: getTopic(q.topicId)?.[lang] ?? q.topicId }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-rule",
								children: "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								txt.question,
								" ",
								index + 1
							] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-xl leading-snug sm:text-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: q.stem[lang] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-2.5",
						children: q.options.map((opt) => {
							const selected = pick === opt.key;
							const isAnswer = opt.key === q.answer;
							const after = shown;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => choose(opt.key),
								disabled: after && mode === "practice",
								className: cn("flex min-h-14 items-start gap-3 rounded-lg border px-3.5 py-3 text-left transition-colors duration-150", "border-rule bg-paper text-ink", selected && !after && "border-ink bg-[#e8e1d3]", after && isAnswer && "border-ok bg-ok-fg text-ink", after && selected && !isAnswer && "border-bad bg-bad-fg text-ink"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("mt-0.5 grid size-8 shrink-0 place-items-center rounded-md border border-rule font-mono text-sm", selected && !after && "border-ink bg-ink text-paper", after && isAnswer && "border-ok bg-ok text-ok-fg", after && selected && !isAnswer && "border-bad bg-bad text-bad-fg"),
										children: opt.key
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pt-1 text-base",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: opt[lang] })
									}),
									after && isAnswer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "ml-auto mt-1 size-4 text-ok" }) : null,
									after && selected && !isAnswer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "ml-auto mt-1 size-4 text-bad" }) : null
								]
							}, opt.key);
						})
					}),
					mode === "practice" && shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 rounded-lg border border-rule bg-[#ebe6db] p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-[11px] uppercase tracking-[0.14em] text-ink-muted",
							children: txt.explanation
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[15px] text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: q.explain[lang] })
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						children: [
							mode === "practice" && !shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ink",
								onClick: check,
								disabled: !pick,
								className: "min-w-32",
								children: txt.check
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ink",
								className: "min-w-32",
								onClick: () => {
									if (mode === "practice" && !shown && pick) check();
									if (index < questions.length - 1) go(index + 1);
									else if (mode === "exam") setConfirm("submit");
									else onExit();
								},
								children: [index === questions.length - 1 ? mode === "exam" ? txt.submit : txt.finish : txt.next, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
							}),
							index > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => go(index - 1),
								children: txt.prev
							}) : null
						]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-24 rounded-xl border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-[11px] uppercase tracking-[0.14em] text-muted",
							children: txt.navGrid
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-5 gap-1.5",
							children: questions.map((item, i) => {
								const has = !!picks[item.id];
								const ok = revealed[item.id] && picks[item.id] === item.answer;
								const bad = revealed[item.id] && picks[item.id] && picks[item.id] !== item.answer;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go(i),
									className: cn("grid h-9 place-items-center rounded-sm text-xs tabular-nums", i === index ? "bg-accent text-accent-fg" : "bg-raised text-muted", has && i !== index && "text-fg", ok && "bg-ok text-ok-fg", bad && "bg-bad text-bad-fg"),
									children: i + 1
								}, item.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted",
							children: [
								answeredCount,
								"/",
								questions.length,
								" ",
								txt.seen
							]
						}),
						mode === "exam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							onClick: () => setConfirm("submit"),
							children: txt.submit
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setShowNav(true),
				className: "fixed bottom-20 right-4 z-20 grid size-12 place-items-center rounded-lg bg-accent text-accent-fg shadow-paper lg:hidden",
				"aria-label": txt.navGrid,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, { className: "size-5" })
			}),
			showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 bg-bg/80 p-4 lg:hidden",
				onClick: () => setShowNav(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-16 max-w-md rounded-xl border border-border bg-surface p-4",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: txt.navGrid
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-6 gap-1.5",
						children: questions.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								go(i);
								setShowNav(false);
							},
							className: cn("grid h-10 place-items-center rounded-sm text-xs", i === index ? "bg-accent text-accent-fg" : "bg-raised text-muted", picks[item.id] && i !== index && "text-fg"),
							children: i + 1
						}, item.id))
					})]
				})
			}) : null,
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 grid place-items-center bg-bg/80 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-xl border border-border bg-surface p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: confirm === "submit" ? txt.confirmSubmit : txt.leaveExam
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "flex-1",
							onClick: () => {
								if (confirm === "submit") finish();
								else onExit();
							},
							children: confirm === "submit" ? txt.yes : txt.leave
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "flex-1",
							onClick: () => setConfirm(null),
							children: confirm === "submit" ? txt.no : txt.stay
						})]
					})]
				})
			}) : null
		]
	});
}
//#endregion
export { QuizView as t };
