import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as cn } from "./router-DGLBVkyc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-CknPAhEX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-colors duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 select-none active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-fg",
			paper: "bg-paper text-ink hover:bg-fg",
			ghost: "bg-transparent text-fg hover:bg-raised border border-border",
			outline: "border border-border bg-surface text-fg hover:bg-raised",
			danger: "bg-bad text-bad-fg hover:opacity-90",
			ink: "bg-ink text-paper hover:opacity-90",
			quiet: "border border-rule bg-transparent text-ink hover:bg-[#e8e1d3]"
		},
		size: {
			sm: "h-10 px-3.5 text-sm rounded-md",
			md: "h-12 px-5 text-sm rounded-lg",
			lg: "h-14 px-6 text-base rounded-lg",
			icon: "size-12 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
//#endregion
export { Button as t };
