import { v as Link, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Play, p as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as useAppStore, n as Route, o as t } from "./router-DGLBVkyc.mjs";
import { a as questionsForTopic, r as getTopic } from "./bank-B_lNkvx6.mjs";
import { t as Button } from "./button-CknPAhEX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topic._topicId-6AqPgARu.js
var import_jsx_runtime = require_jsx_runtime();
function TopicPage() {
	const { topicId } = Route.useParams();
	const navigate = useNavigate();
	const topic = getTopic(topicId);
	const lang = useAppStore((s) => s.lang);
	const attempts = useAppStore((s) => s.attempts);
	const txt = t(lang);
	const qs = questionsForTopic(topicId);
	const done = qs.filter((q) => attempts[q.id]?.correct).length;
	if (!topic) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Missing topic."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-3 inline-block text-sm underline",
		children: txt.home
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => navigate({ to: "/" }),
				className: "mb-6 inline-flex h-11 items-center gap-1 text-sm text-muted hover:text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), txt.back]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] uppercase tracking-[0.16em] text-muted",
				children: [
					topic.group === "mat1" ? txt.mat1 : txt.mat2,
					" · ",
					String(topic.order).padStart(2, "0")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl tracking-tight",
				children: topic[lang]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: lang === "bn" ? topic.blurbBn : topic.blurbTr
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						k: txt.questions,
						v: String(qs.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						k: txt.mastered,
						v: String(done)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						k: txt.accuracy,
						v: qs.length ? `${Math.round(done / qs.length * 100)}%` : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "flex-1",
					onClick: () => navigate({
						to: "/practice/$topicId",
						params: { topicId },
						search: { mode: "practice" }
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), txt.practice]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "outline",
					className: "flex-1",
					onClick: () => navigate({
						to: "/practice/$topicId",
						params: { topicId },
						search: { mode: "exam" }
					}),
					children: txt.examMode
				})]
			})
		]
	});
}
function Mini({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-[0.12em] text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums",
			children: v
		})]
	});
}
//#endregion
export { TopicPage as component };
