import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as House, d as BookOpen, n as TriangleAlert, o as ClipboardList, r as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DGLBVkyc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var copy = {
	bn: {
		app: "TRYOS Helper",
		tagline: "TR-YÖS Metropol গণিত — অধ্যায়ভিত্তিক অনুশীলন",
		home: "হোম",
		topics: "বিষয়",
		mock: "মক টেস্ট",
		review: "ভুলগুলো",
		continue: "যেখানে ছিলে",
		start: "শুরু করো",
		resume: "আবার চালাও",
		practice: "অনুশীলন",
		examMode: "পরীক্ষা মোড",
		check: "যাচাই করো",
		next: "পরের প্রশ্ন",
		prev: "আগের",
		explanation: "ব্যাখ্যা",
		correct: "সঠিক",
		wrong: "ভুল",
		skip: "এড়িয়ে যাও",
		finish: "শেষ করো",
		progress: "অগ্রগতি",
		mastered: "আয়ত্ত",
		remaining: "বাকি",
		questions: "প্রশ্ন",
		mat1: "গণিত ১",
		mat2: "গণিত ২",
		mockTitle: "পূর্ণ মক টেস্ট",
		mockBlurb: "৪০টি প্রশ্ন · ৫০ মিনিট · তাৎক্ষণিক উত্তর নেই · TR-YÖS গণিত অংশের ধরন",
		startMock: "মক শুরু",
		submit: "জমা দাও",
		timeLeft: "সময়",
		score: "স্কোর",
		result: "ফলাফল",
		again: "আবার দাও",
		homeCta: "বিষয়ে ফিরে যাও",
		emptyReview: "এখনো কোনো ভুল নেই। একটি বিষয় খুলে অনুশীলন করো।",
		of: "/",
		langLabel: "বাংলা",
		pickAnswer: "একটি উত্তর বেছে নাও",
		confirmSubmit: "জমা দিলে আর বদলানো যাবে না। নিশ্চিত?",
		yes: "হ্যাঁ, জমা দাও",
		no: "ফিরে যাই",
		leaveExam: "পরীক্ষা ছেড়ে যাবে?",
		leave: "ছেড়ে যাও",
		stay: "থাকো",
		unanswered: "ফাঁকা",
		topicBreakdown: "বিষয় অনুসারে",
		bookNote: "বইয়ের অধ্যায় অনুসারে সাজানো মূল প্রশ্ন — কপি নয়, একই সিলেবাসে নতুন অনুশীলন।",
		allTopics: "সব অধ্যায়",
		lastScore: "শেষ মক",
		seen: "করা হয়েছে",
		accuracy: "সঠিকতার হার",
		question: "প্রশ্ন",
		done: "সম্পন্ন",
		startTopic: "এই অধ্যায় শুরু",
		back: "পিছনে",
		navGrid: "প্রশ্ন তালিকা",
		mockDone: "সময় শেষ — উত্তর জমা পড়েছে",
		noPenalty: "নেগেটিভ মার্কিং নেই। শুধু সঠিক উত্তর গণনা হয়।",
		difficulty: "কঠিনতা",
		easy: "সহজ",
		mid: "মাঝারি",
		hard: "কঠিন"
	},
	tr: {
		app: "TRYOS Helper",
		tagline: "TR-YÖS Metropol matematik — konu konu alıştırma",
		home: "Ana sayfa",
		topics: "Konular",
		mock: "Deneme",
		review: "Yanlışlar",
		continue: "Kaldığın yer",
		start: "Başla",
		resume: "Devam et",
		practice: "Alıştırma",
		examMode: "Sınav modu",
		check: "Kontrol et",
		next: "Sonraki",
		prev: "Önceki",
		explanation: "Çözüm",
		correct: "Doğru",
		wrong: "Yanlış",
		skip: "Atla",
		finish: "Bitir",
		progress: "İlerleme",
		mastered: "Pekişen",
		remaining: "Kalan",
		questions: "soru",
		mat1: "Matematik 1",
		mat2: "Matematik 2",
		mockTitle: "Tam deneme",
		mockBlurb: "40 soru · 50 dakika · anında cevap yok · TR-YÖS matematik oturumu",
		startMock: "Denemeyi başlat",
		submit: "Kaydet",
		timeLeft: "Süre",
		score: "Puan",
		result: "Sonuç",
		again: "Yeniden çöz",
		homeCta: "Konulara dön",
		emptyReview: "Henüz yanlış yok. Bir konu açıp çalış.",
		of: "/",
		langLabel: "Türkçe",
		pickAnswer: "Bir şık seç",
		confirmSubmit: "Gönderince değiştirilemez. Emin misin?",
		yes: "Evet, gönder",
		no: "Geri dön",
		leaveExam: "Sınavdan çıkılsın mı?",
		leave: "Çık",
		stay: "Kal",
		unanswered: "Boş",
		topicBreakdown: "Konuya göre",
		bookNote: "Kitap bölümlerine göre sıralı özgün sorular — kopya değil, aynı müfredat.",
		allTopics: "Tüm konular",
		lastScore: "Son deneme",
		seen: "çözülen",
		accuracy: "doğruluk",
		question: "Soru",
		done: "bitti",
		startTopic: "Bu konuya başla",
		back: "Geri",
		navGrid: "Soru listesi",
		mockDone: "Süre bitti — cevaplar kaydedildi",
		noPenalty: "Negatif puan yok. Yalnızca doğrular sayılır.",
		difficulty: "Zorluk",
		easy: "kolay",
		mid: "orta",
		hard: "zor"
	}
};
function t(lang) {
	return copy[lang];
}
var useAppStore = create()(persist((set) => ({
	lang: "bn",
	attempts: {},
	lastTopicId: null,
	lastIndex: {},
	mockHistory: [],
	setLang: (lang) => set({ lang }),
	recordAttempt: (questionId, picked, correct) => set((s) => ({ attempts: {
		...s.attempts,
		[questionId]: {
			picked,
			correct,
			at: Date.now()
		}
	} })),
	setLast: (topicId, index) => set((s) => ({
		lastTopicId: topicId,
		lastIndex: {
			...s.lastIndex,
			[topicId]: index
		}
	})),
	addMock: (rec) => set((s) => ({ mockHistory: [rec, ...s.mockHistory].slice(0, 12) })),
	clearAttemptsFor: (questionIds) => set((s) => {
		const next = { ...s.attempts };
		for (const id of questionIds) delete next[id];
		return { attempts: next };
	})
}), { name: "tryos-helper-v1" }));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var NAV = [
	{
		to: "/",
		key: "home",
		icon: House
	},
	{
		to: "/mock",
		key: "mock",
		icon: ClipboardList
	},
	{
		to: "/review",
		key: "review",
		icon: RotateCcw
	}
];
function AppShell({ children }) {
	const lang = useAppStore((s) => s.lang);
	const setLang = useAppStore((s) => s.setLang);
	const txt = t(lang);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-center gap-3 min-h-11",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-9 items-center justify-center rounded-md bg-paper text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
									className: "size-4",
									strokeWidth: 1.75
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "leading-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-lg tracking-tight",
									children: txt.app
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden text-[11px] uppercase tracking-[0.16em] text-muted sm:block",
									children: "TR-YÖS"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 md:flex",
							children: NAV.map((item) => {
								const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
								const Icon = item.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									className: cn("inline-flex h-11 items-center gap-2 rounded-md px-3.5 text-sm", active ? "bg-raised text-fg" : "text-muted hover:bg-surface hover:text-fg"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4",
										strokeWidth: 1.75
									}), txt[item.key]]
								}, item.to);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLang(lang === "bn" ? "tr" : "bn"),
							className: "h-11 min-w-11 rounded-md border border-border px-3 text-sm text-fg hover:bg-raised",
							"aria-label": "language",
							children: lang === "bn" ? "TR" : "বাং"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-6xl px-4 pb-28 pt-6 md:pb-12 md:pt-8",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur-md md:hidden pb-[env(safe-area-inset-bottom)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-fg" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.75
							}), txt[item.key]]
						}, item.to);
					})
				})
			})
		]
	});
}
var styles_default = "/assets/styles-D0BeuoAh.css";
var APP_NAME = "TRYOS Helper";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0d10"
			},
			{
				name: "description",
				content: "TR-YÖS Metropol matematik — konu konu interaktif alıştırma ve deneme."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&family=IBM+Plex+Mono:wght@500&family=Instrument+Serif:ital@0;1&family=Noto+Sans+Bengali:wght@400;500;600&family=Noto+Serif+Bengali:wght@500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "bn",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$5 = () => import("./routes-CDO5n0Zq.mjs");
var Route$5 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./exam-BIolPgva.mjs");
var Route$4 = createFileRoute("/exam")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./mock-CkLiMzgQ.mjs");
var Route$3 = createFileRoute("/mock")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./review-oGC7KL-m.mjs");
var Route$2 = createFileRoute("/review")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./practice._topicId-LyNC7o1b.mjs");
var Route$1 = createFileRoute("/practice/$topicId")({
	validateSearch: (s) => ({ mode: s.mode === "exam" ? "exam" : "practice" }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./topic._topicId-6AqPgARu.mjs");
var Route = createFileRoute("/topic/$topicId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	ExamRoute: Route$4.update({
		id: "/exam",
		path: "/exam",
		getParentRoute: () => Route$6
	}),
	MockRoute: Route$3.update({
		id: "/mock",
		path: "/mock",
		getParentRoute: () => Route$6
	}),
	ReviewRoute: Route$2.update({
		id: "/review",
		path: "/review",
		getParentRoute: () => Route$6
	}),
	PracticeTopicIdRoute: Route$1.update({
		id: "/practice/$topicId",
		path: "/practice/$topicId",
		getParentRoute: () => Route$6
	}),
	TopicTopicIdRoute: Route.update({
		id: "/topic/$topicId",
		path: "/topic/$topicId",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useAppStore as a, cn as i, Route as n, t as o, Route$1 as r, router_exports as t };
