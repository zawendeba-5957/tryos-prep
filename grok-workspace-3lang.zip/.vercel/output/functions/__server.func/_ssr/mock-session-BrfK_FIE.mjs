//#region node_modules/.nitro/vite/services/ssr/assets/mock-session-BrfK_FIE.js
var MOCK_KEY = "tryos-mock-live";
var MOCK_RESULT = "tryos-mock-result";
//#endregion
export { MOCK_RESULT as n, MOCK_KEY as t };
