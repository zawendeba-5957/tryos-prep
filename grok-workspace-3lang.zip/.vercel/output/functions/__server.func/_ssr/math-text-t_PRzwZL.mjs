import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as cn } from "./router-DGLBVkyc.mjs";
import { t as katex } from "../_libs/katex.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/math-text-t_PRzwZL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function renderChunk(chunk, display) {
	try {
		return katex.renderToString(chunk, {
			displayMode: display,
			throwOnError: false,
			strict: "ignore"
		});
	} catch {
		return chunk;
	}
}
function MathText({ text, className }) {
	const parts = (0, import_react.useMemo)(() => {
		const re = /(\$\$[\s\S]+?\$\$|\$[^$]+\$)/g;
		const out = [];
		let last = 0;
		let m;
		while (m = re.exec(text)) {
			if (m.index > last) out.push({ text: text.slice(last, m.index) });
			const raw = m[0];
			const display = raw.startsWith("$$");
			const body = display ? raw.slice(2, -2) : raw.slice(1, -1);
			out.push({
				html: renderChunk(body, display),
				display
			});
			last = m.index + raw.length;
		}
		if (last < text.length) out.push({ text: text.slice(last) });
		return out;
	}, [text]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("leading-relaxed", className),
		children: parts.map((p, i) => p.html ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: p.display ? "my-2 block overflow-x-auto" : "inline",
			dangerouslySetInnerHTML: { __html: p.html }
		}, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.text }, i))
	});
}
//#endregion
export { MathText as t };
