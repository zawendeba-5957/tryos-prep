import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useAppStore, o as t, r as Route$1 } from "./router-DGLBVkyc.mjs";
import { a as questionsForTopic, r as getTopic } from "./bank-B_lNkvx6.mjs";
import { t as Button } from "./button-CknPAhEX.mjs";
import { t as QuizView } from "./quiz-view-OPJnXV7O.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice._topicId-LyNC7o1b.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PracticePage() {
	const { topicId } = Route$1.useParams();
	const { mode = "practice" } = Route$1.useSearch();
	const navigate = useNavigate();
	const lang = useAppStore((s) => s.lang);
	const txt = t(lang);
	const topic = getTopic(topicId);
	const questions = (0, import_react.useMemo)(() => questionsForTopic(topicId), [topicId]);
	const [summary, setSummary] = (0, import_react.useState)(null);
	if (!topic || questions.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-muted",
		children: [
			"Missing.",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "underline",
				onClick: () => navigate({ to: "/" }),
				children: txt.home
			})
		]
	});
	if (summary) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md rounded-xl border border-border bg-surface p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.14em] text-muted",
				children: topic[lang]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: txt.result
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 font-display text-5xl tabular-nums",
				children: [summary.score, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-2xl text-muted",
					children: ["/", summary.total]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "flex-1",
					onClick: () => setSummary(null),
					children: txt.again
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "flex-1",
					onClick: () => navigate({ to: "/" }),
					children: txt.homeCta
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizView, {
		questions,
		mode,
		sessionKey: topicId,
		onExit: () => navigate({
			to: "/topic/$topicId",
			params: { topicId }
		}),
		onComplete: (r) => {
			if (mode === "exam") setSummary({
				score: r.score,
				total: r.total
			});
			else navigate({
				to: "/topic/$topicId",
				params: { topicId }
			});
		}
	});
}
//#endregion
export { PracticePage as component };
