import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as ClipboardList } from "../_libs/lucide-react.mjs";
import { a as useAppStore, o as t } from "./router-DGLBVkyc.mjs";
import { i as pickMockPaper } from "./bank-B_lNkvx6.mjs";
import { t as Button } from "./button-CknPAhEX.mjs";
import { n as MOCK_RESULT, t as MOCK_KEY } from "./mock-session-BrfK_FIE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mock-CkLiMzgQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MockPage() {
	const lang = useAppStore((s) => s.lang);
	const txt = t(lang);
	const history = useAppStore((s) => s.mockHistory);
	const navigate = useNavigate();
	const [lastResult, setLastResult] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		try {
			setLastResult(JSON.parse(sessionStorage.getItem("tryos-mock-result") || "null"));
		} catch {
			setLastResult(null);
		}
	}, []);
	function start() {
		const paper = pickMockPaper(40);
		sessionStorage.setItem(MOCK_KEY, JSON.stringify({
			ids: paper.map((q) => q.id),
			started: Date.now()
		}));
		sessionStorage.removeItem(MOCK_RESULT);
		navigate({ to: "/exam" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.16em] text-muted",
				children: "TR-YÖS"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl tracking-tight",
				children: txt.mockTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: txt.mockBlurb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-subtle",
				children: txt.noPenalty
			}),
			lastResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-xl bg-paper p-5 text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.14em] text-ink-muted",
					children: txt.result
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-display text-5xl tabular-nums",
					children: [lastResult.score, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-2xl text-ink-muted",
						children: ["/", lastResult.total]
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				className: "mt-8 min-h-14 w-full sm:w-auto",
				onClick: start,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4" }), txt.startMock]
			}),
			history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: txt.lastScore
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border rounded-xl border border-border",
					children: history.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: new Date(h.at).toLocaleDateString(lang === "bn" ? "bn-BD" : "tr-TR")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								h.score,
								"/",
								h.total
							]
						})]
					}, h.id))
				})]
			}) : null
		]
	});
}
//#endregion
export { MockPage as component };
