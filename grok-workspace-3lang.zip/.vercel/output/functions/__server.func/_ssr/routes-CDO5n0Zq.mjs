import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as ArrowRight, o as ClipboardList } from "../_libs/lucide-react.mjs";
import { a as useAppStore, i as cn, o as t } from "./router-DGLBVkyc.mjs";
import { a as questionsForTopic, n as TOPICS, t as QUESTIONS } from "./bank-B_lNkvx6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CDO5n0Zq.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const lang = useAppStore((s) => s.lang);
	const attempts = useAppStore((s) => s.attempts);
	const lastTopicId = useAppStore((s) => s.lastTopicId);
	const mockHistory = useAppStore((s) => s.mockHistory);
	const txt = t(lang);
	const answered = Object.keys(attempts).length;
	const correct = Object.values(attempts).filter((a) => a.correct).length;
	const last = TOPICS.find((x) => x.id === lastTopicId);
	const lastMock = mockHistory[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-[1.4fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-muted",
						children: "TR-YÖS · Metropol"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl",
						children: txt.app
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-muted",
						children: txt.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-subtle",
						children: txt.bookNote
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3 self-end sm:grid-cols-3 lg:grid-cols-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: txt.seen,
							value: `${answered}/${QUESTIONS.length}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: txt.accuracy,
							value: answered ? `${Math.round(correct / answered * 100)}%` : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: txt.lastScore,
							value: lastMock ? `${lastMock.score}/${lastMock.total}` : "—",
							className: "col-span-2 sm:col-span-1"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/practice/$topicId",
					params: { topicId: last.id },
					className: "flex min-h-24 items-center justify-between rounded-xl border border-border bg-surface px-5 py-4 hover:bg-raised",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[11px] uppercase tracking-[0.14em] text-muted",
						children: txt.continue
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-2xl",
						children: last[lang]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5 text-muted" })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/topic/$topicId",
					params: { topicId: TOPICS[0].id },
					className: "flex min-h-24 items-center justify-between rounded-xl border border-border bg-surface px-5 py-4 hover:bg-raised",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[11px] uppercase tracking-[0.14em] text-muted",
						children: txt.start
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-2xl",
						children: TOPICS[0][lang]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5 text-muted" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/mock",
					className: "flex min-h-24 items-center justify-between rounded-xl bg-paper px-5 py-4 text-ink hover:opacity-95",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[11px] uppercase tracking-[0.14em] text-ink-muted",
						children: txt.mock
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-2xl",
						children: txt.mockTitle
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-5" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
				title: txt.mat1,
				topics: TOPICS.filter((x) => x.group === "mat1"),
				lang,
				attempts
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
				title: txt.mat2,
				topics: TOPICS.filter((x) => x.group === "mat2"),
				lang,
				attempts
			})
		]
	});
}
function Stat({ label, value, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-xl border border-border bg-surface px-4 py-3", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-[0.14em] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
function Group({ title, topics, lang, attempts }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "mb-3 font-display text-2xl",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3",
		children: topics.map((topic) => {
			const qs = questionsForTopic(topic.id);
			const done = qs.filter((q) => attempts[q.id]?.correct).length;
			const pct = qs.length ? Math.round(done / qs.length * 100) : 0;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/topic/$topicId",
				params: { topicId: topic.id },
				className: "rounded-lg border border-border bg-surface p-4 hover:bg-raised",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs tabular-nums text-muted",
							children: String(topic.order).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs tabular-nums text-muted",
							children: [pct, "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 font-display text-xl leading-tight",
						children: topic[lang]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-2 text-sm text-muted",
						children: lang === "bn" ? topic.blurbBn : topic.blurbTr
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-1 overflow-hidden rounded-full bg-raised",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent",
							style: { width: `${pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-subtle",
						children: [
							done,
							"/",
							qs.length
						]
					})
				]
			}, topic.id);
		})
	})] });
}
//#endregion
export { Home as component };
