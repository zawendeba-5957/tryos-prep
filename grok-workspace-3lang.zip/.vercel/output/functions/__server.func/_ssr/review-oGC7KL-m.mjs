import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useAppStore, o as t } from "./router-DGLBVkyc.mjs";
import { r as getTopic, t as QUESTIONS } from "./bank-B_lNkvx6.mjs";
import { t as MathText } from "./math-text-t_PRzwZL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/review-oGC7KL-m.js
var import_jsx_runtime = require_jsx_runtime();
function ReviewPage() {
	const lang = useAppStore((s) => s.lang);
	const attempts = useAppStore((s) => s.attempts);
	const txt = t(lang);
	const wrong = QUESTIONS.filter((q) => attempts[q.id] && !attempts[q.id].correct);
	if (wrong.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: txt.review
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: txt.emptyReview
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-block text-sm underline underline-offset-4",
				children: txt.homeCta
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: txt.review
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted",
				children: [
					wrong.length,
					" ",
					txt.questions
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-3",
				children: wrong.map((q) => {
					const topic = getTopic(q.topicId);
					const picked = attempts[q.id]?.picked;
					const pickText = q.options.find((o) => o.key === picked)?.[lang] ?? "—";
					const ansText = q.options.find((o) => o.key === q.answer)?.[lang] ?? "";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-border bg-surface p-4 sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] uppercase tracking-[0.14em] text-muted",
								children: topic?.[lang]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: q.stem[lang] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-sm text-bad-fg",
								children: [
									txt.wrong,
									": ",
									picked,
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: pickText })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-ok-fg",
								children: [
									txt.correct,
									": ",
									q.answer,
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: ansText })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathText, { text: q.explain[lang] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/practice/$topicId",
								params: { topicId: q.topicId },
								className: "mt-3 inline-block text-sm underline underline-offset-4",
								children: txt.startTopic
							})
						]
					}, q.id);
				})
			})
		]
	});
}
//#endregion
export { ReviewPage as component };
