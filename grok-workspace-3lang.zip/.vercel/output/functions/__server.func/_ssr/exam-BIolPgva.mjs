import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useAppStore, o as t } from "./router-DGLBVkyc.mjs";
import { t as QUESTIONS } from "./bank-B_lNkvx6.mjs";
import { t as QuizView } from "./quiz-view-OPJnXV7O.mjs";
import { n as MOCK_RESULT, t as MOCK_KEY } from "./mock-session-BrfK_FIE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam-BIolPgva.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function loadPaper() {
	try {
		const raw = sessionStorage.getItem(MOCK_KEY);
		if (!raw) return [];
		const { ids } = JSON.parse(raw);
		const map = new Map(QUESTIONS.map((q) => [q.id, q]));
		return ids.map((id) => map.get(id)).filter(Boolean);
	} catch {
		return [];
	}
}
function ExamPage() {
	const navigate = useNavigate();
	const lang = useAppStore((s) => s.lang);
	const txt = t(lang);
	const addMock = useAppStore((s) => s.addMock);
	const recordAttempt = useAppStore((s) => s.recordAttempt);
	const [questions, setQuestions] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setQuestions(loadPaper());
	}, []);
	if (questions === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-muted",
		children: [txt.progress, "…"]
	});
	if (questions.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: txt.mockBlurb
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-4 underline",
			onClick: () => navigate({ to: "/mock" }),
			children: txt.back
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizView, {
		questions,
		mode: "exam",
		sessionKey: "mock",
		timerSeconds: 3e3,
		onExit: () => navigate({ to: "/mock" }),
		onComplete: (r) => {
			for (const q of questions) {
				const picked = r.picks[q.id];
				if (picked) recordAttempt(q.id, picked, picked === q.answer);
			}
			addMock({
				id: String(Date.now()),
				at: Date.now(),
				score: r.score,
				total: r.total,
				seconds: r.seconds
			});
			sessionStorage.setItem(MOCK_RESULT, JSON.stringify({
				score: r.score,
				total: r.total
			}));
			sessionStorage.removeItem(MOCK_KEY);
			navigate({ to: "/mock" });
		}
	});
}
//#endregion
export { ExamPage as component };
